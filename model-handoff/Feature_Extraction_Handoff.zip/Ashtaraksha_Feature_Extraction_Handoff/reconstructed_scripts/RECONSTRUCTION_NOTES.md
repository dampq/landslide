# Reconstructed web-coordinate adapter: scope and assumptions

`feature_extraction/coordinate_feature_extractor.py` is a newly assembled one-coordinate adapter based on the recovered functions in the copied original scripts. It was not used to train either existing model. No trained classifier or parameter was changed.

Recovered from original code:

- V1's `raster_value()`, `static_features()` and soil conversions in `Ashtaraksha_Model/train_random_forest.py`.
- V2's regional raster sampling and `terrain_features()` calculation in `Ashtaraksha_Model/Version_2/collect_worldclim_regional.py`.
- V2's reuse of V1 environmental features and ID-checked join in `Ashtaraksha_Model/Version_2/train_random_forest_v2.py`.
- Exact trained feature columns and category order checked against `feature_list*.json` and each saved preprocessing pipeline's `get_feature_names_out()`.

Reconstruction choices (not historical claims):

1. Combines the original V1 static feature sampler and V2 regional sampler behind one latitude/longitude API.
2. Checks that the coordinate lies within a polygon in the included eight-state boundary.
3. Converts coordinate CRS if a deployed raster is not EPSG:4326. The original training rasters are all EPSG:4326, and the original code passed longitude/latitude directly; this conversion branch is not part of the training implementation and is only a defensive deployment convenience.
4. Returns source NoData/outside-raster values as JSON `null` plus diagnostics; it does not apply new feature-level fills. The serialized fitted model pipeline is responsible for the same training-time imputation rules. The existing strict V1 HTTP schema accepts only finite numeric inputs, so its example API abstains if any required V1 feature is missing.
5. Uses fixed local source paths in editable `feature_extraction/config.json`. The package includes the small boundary file, but intentionally does not bundle the large raster collections.

`processed/preprocessing_scripts/extract_permitted_features.py` was audited but is not copied as a V1/V2 source: its own header says it was syntax-checked only and not executed; it describes a different event-day/CHIRPS extraction path, with DEM features withheld. The Colab notebook is a validation/clipping test, not the source of the trained V1/V2 tables. None of those files is represented as the implementation used by the saved models.

The separate `Ashtaraksha_Model/Version_2/train_random_forest.py` was also inspected. Its docstring describes an earlier CHIRPS-normal workflow, while the saved V2 model's metadata, feature list and actual training script identify WorldClim BIO and terrain predictors. It is not copied as the source for the current saved V2 model. CHIRPS is not an input to either delivered model schema.
