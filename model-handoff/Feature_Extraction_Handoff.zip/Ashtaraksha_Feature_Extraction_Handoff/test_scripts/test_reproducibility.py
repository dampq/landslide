"""Real-data regression checks for the coordinate feature adapter and models."""
from __future__ import annotations

import json
import importlib.util
import math
import sys
import unittest
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

PACKAGE = Path(__file__).resolve().parents[1]
PROJECT = PACKAGE.parent
sys.path.insert(0, str(PACKAGE / "feature_extraction"))
from coordinate_feature_extractor import (  # noqa: E402
    InvalidCoordinateError, SourceDataUnavailableError, UnsupportedLocationError,
    _sample, extract_coordinate,
)

MODEL_DIR = PROJECT / "Ashtaraksha_Model"
V2_DIR = MODEL_DIR / "Version_2"


def load_helper(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class ReproducibilityTests(unittest.TestCase):
    def test_event_467_raw_features_and_predictions(self):
        example1 = json.loads((PACKAGE / "reproducible_examples/event_id_467_v1.json").read_text(encoding="utf-8"))
        example2 = json.loads((PACKAGE / "reproducible_examples/event_id_467_v2.json").read_text(encoding="utf-8"))
        extracted = extract_coordinate(26.19, 91.71)
        self.assertEqual(extracted["state"], "Assam")
        for version, example in (("v1", example1), ("v2", example2)):
            self.assertEqual(extracted[f"{version}_features"], example["raw_features"])
            feature_file = MODEL_DIR / "feature_list.json" if version == "v1" else V2_DIR / "feature_list_v2.json"
            schema = json.loads(feature_file.read_text(encoding="utf-8"))
            model_path = MODEL_DIR / "ashtaraksha_random_forest.joblib" if version == "v1" else V2_DIR / "ashtaraksha_random_forest_v2.joblib"
            prep_path = MODEL_DIR / "preprocessing_pipeline.joblib" if version == "v1" else V2_DIR / "preprocessing_pipeline_v2.joblib"
            model, prep = joblib.load(model_path), joblib.load(prep_path)
            frame = pd.DataFrame([example["raw_features"]], columns=schema["raw_features"])
            transformed = prep.transform(frame)
            names = list(prep.get_feature_names_out())
            self.assertEqual(names, example["transformed_feature_order"])
            np.testing.assert_allclose(transformed[0], example["transformed_model_inputs"], rtol=0, atol=1e-10)
            score = float(model.predict_proba(transformed)[0, 1])
            self.assertTrue(math.isclose(score, example["expected_score_verified"], rel_tol=0, abs_tol=1e-12))
            helper_path = MODEL_DIR / "predict.py" if version == "v1" else V2_DIR / "predict_v2.py"
            helper_score = load_helper(f"test_predict_{version}", helper_path).predict_relative_score(example["raw_features"])["experimental_presence_background_score"]
            self.assertTrue(math.isclose(helper_score, example["expected_score_verified"], rel_tol=0, abs_tol=1e-12))

    def test_invalid_coordinates(self):
        for lat, lon in ((float("nan"), 91.0), (91.0, 91.0), (26.0, float("inf")), ("north", 91.0)):
            with self.subTest(lat=lat, lon=lon), self.assertRaises(InvalidCoordinateError):
                extract_coordinate(lat, lon)

    def test_location_outside_ner_rejected(self):
        with self.assertRaises(UnsupportedLocationError):
            extract_coordinate(0, 0)

    def test_missing_worldclim_cell_reported_as_null(self):
        # Real saved training background point BG_2833_1 in Sikkim, whose BIO
        # source pixels are NoData. This checks coverage/missing handling.
        got = extract_coordinate(27.580541458184456, 88.78446248500114)
        for name in ("bio12_annual_precipitation_mm", "bio13_wettest_month_precip_mm",
                     "bio15_precipitation_seasonality_pct", "bio16_wettest_quarter_precip_mm",
                     "bio17_driest_quarter_precip_mm"):
            self.assertIsNone(got["v2_features"][name])
            self.assertEqual(got["source_status"]["v2"][name], "SOURCE_NODATA_OR_OUTSIDE_RASTER")

    def test_missing_soil_vector_reported_as_null(self):
        # Real saved GFLD row event_id 4177; source pH encoding signals the
        # all-zero/no-nodata soil vector condition in the original V1 script.
        got = extract_coordinate(27.081, 93.601)
        for name in ("clay_fraction", "sand_fraction", "soil_ph", "soc_stock_t_ha"):
            self.assertIsNone(got["v1_features"][name])
            self.assertIn(name, got["missing_features"]["v1"])

    def test_missing_raster_file_fails_closed(self):
        with self.assertRaises(SourceDataUnavailableError):
            _sample(PACKAGE / "feature_extraction" / "data" / "not_a_real_raster.tif", 91.71, 26.19)

    def test_transformed_feature_order_matches_fitted_models(self):
        checks = ((MODEL_DIR / "feature_list.json", MODEL_DIR / "preprocessing_pipeline.joblib", 13),
                  (V2_DIR / "feature_list_v2.json", V2_DIR / "preprocessing_pipeline_v2.joblib", 22))
        for schema_path, prep_path, count in checks:
            schema = json.loads(schema_path.read_text(encoding="utf-8"))
            prep = joblib.load(prep_path)
            self.assertEqual(list(prep.get_feature_names_out()), schema["transformed_features"])
            self.assertEqual(len(schema["transformed_features"]), count)


if __name__ == "__main__":
    unittest.main(verbosity=2)
