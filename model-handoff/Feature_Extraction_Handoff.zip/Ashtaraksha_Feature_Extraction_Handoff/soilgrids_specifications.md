# SoilGrids specifications recovered from V1

## Verified source layers

The four actual rasters used by `Ashtaraksha_Model/train_random_forest.py` are under `Ashtaraksha_Datasets/Soil_Geology/SoilGrids_2.0_NER/`. They are SoilGrids 2.0 WCS subsets, median prediction (`Q0.5`) for 0–5 cm, EPSG:4326, 4,424 × 3,431 pixels, with WCS output spacing 0.00226039783° × 0.00238997377° (roughly 250 m). The WCS files have **no GDAL_NODATA tag**. This limitation is explicitly recorded in the local source report and inventory.

| Model input | Raster | Product layer | Source value and conversion | Model value |
|---|---|---|---|---|
| `clay_fraction` | `SoilGrids2_clay_0-5cm_Q0.5_NER_bbox_EPSG4326.tif` | `clay_0-5cm_Q0.5` | Clay mass fraction in per mille; divide by 1000 | Fraction, 0–1 |
| `sand_fraction` | `SoilGrids2_sand_0-5cm_Q0.5_NER_bbox_EPSG4326.tif` | `sand_0-5cm_Q0.5` | Sand mass fraction in per mille; divide by 1000 | Fraction, 0–1 |
| `soil_ph` | `SoilGrids2_phh2o_0-5cm_Q0.5_NER_bbox_EPSG4326.tif` | `phh2o_0-5cm_Q0.5` | pH in water encoded as pH × 10; divide by 10 | pH |
| `soc_stock_t_ha` | `SoilGrids2_soc_0-5cm_Q0.5_NER_bbox_EPSG4326.tif` | `soc_0-5cm_Q0.5` | Soil organic carbon **stock**, already tonnes/hectare | t/ha; no conversion |

## Exact missing-value logic in the original V1 training script

`raster_value()` returns NaN for masked or non-finite pixel values. Since these regional SoilGrids files do not declare a NoData value, the original script uses the sampled pH encoding as a sentinel: if pH is finite and `<= 0` or `> 140`, it marks the entire four-property vector missing. Clay/sand values `>1000` per mille are separately set missing. Valid clay/sand are divided by 1000; pH is divided by 10; SOC stock is passed unchanged. No bulk-density/depth/concentration conversion is applied to SOC.

This rule is an explicit heuristic because the service response did not expose a NoData code. It can classify an all-zero pixel vector as missing; do not reinterpret zero as observed soil. The fitted pipelines impute continuous missing inputs using their fitted median imputer. Existing strict V1 FastAPI validation still requires finite inputs and does not accept null soil values. The coordinate adapter therefore returns a missing status; its example API abstains from V1 scoring when required inputs are missing. V2's prediction helper accepts continuous nulls and applies its stored imputer.

## Licence and attribution

SoilGrids 2.0 is CC BY 4.0. Attribute ISRIC – World Soil Information and cite Poggio et al. (2021), DOI 10.5194/soil-7-217-2021. Official references: [SoilGrids WCS](https://docs.isric.org/globaldata/soilgrids/wcs.html) and [licence/access FAQ](https://docs.isric.org/globaldata/soilgrids/SoilGrids_faqs_02.html).
