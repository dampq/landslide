"""Train a small exploratory, presence-background Random Forest for Ashtaraksha.

This is a reproducible research prototype, not an operational risk model. The
GFLD coordinates are source centroids without per-record uncertainty in the
downloaded service. Sampled background rows are unknown locations, never
confirmed landslide absences. See model_evaluation_report.md before use.
"""
from __future__ import annotations

import json
import math
import random
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZipFile

import geopandas as gpd
import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio.io import MemoryFile
from shapely.geometry import Point
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (average_precision_score, confusion_matrix,
                             ConfusionMatrixDisplay, f1_score,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "Ashtaraksha_Datasets"
OUT = Path(__file__).resolve().parent
INVENTORY = DATA / "Landslide_Inventory" / "GFLD_2017_OGLv2_NER"
BOUNDARY = DATA / "Rainfall" / "Boundaries" / "NER_8_states.geojson"
WC_DIR = DATA / "Land_Cover" / "WorldCover_2021_v200_tiles"
SOIL_DIR = DATA / "Soil_Geology" / "SoilGrids_2.0_NER"
SEED = 20261111
BACKGROUND_PER_EVENT = 1
MIN_BACKGROUND_DISTANCE_KM = 10.0
BLOCK_SIZE_M = 100_000.0
N_SPLITS = 5

FEATURES = ["worldcover_class", "clay_fraction", "sand_fraction",
            "soil_ph", "soc_stock_t_ha"]
CAT = ["worldcover_class"]
NUM = ["clay_fraction", "sand_fraction", "soil_ph", "soc_stock_t_ha"]


def read_events() -> gpd.GeoDataFrame:
    """Merge source layers and deduplicate using the GFLD source event ID."""
    records = {}
    source_file = {}
    for path in sorted(INVENTORY.glob("*.geojson"), key=lambda p: ("All_rainfall" not in p.name, p.name)):
        doc = json.loads(path.read_text(encoding="utf-8"))
        for f in doc.get("features", []):
            props = f.get("properties", {})
            event_id = str(props.get("Total_numb", "")).strip()
            if not event_id or event_id == "None":
                continue
            if event_id in records:
                continue
            geom = f.get("geometry") or {}
            xy = geom.get("coordinates", [])
            if geom.get("type") != "Point" or len(xy) < 2:
                continue
            records[event_id] = {
                "event_id": event_id,
                "longitude": float(xy[0]), "latitude": float(xy[1]),
                "event_year": int(props["Year"]) if props.get("Year") else None,
                "event_month": int(props["Month"]) if props.get("Month") else None,
                "event_day": int(props["Day"]) if props.get("Day") else None,
                "fatalities": props.get("Fatalities"),
                "country": props.get("Country2"),
            }
            source_file[event_id] = path.name
    rows = pd.DataFrame(records.values())
    rows["source_layer_file"] = rows.event_id.map(source_file)
    # Collapse exact duplicate occurrence representations (same coordinates and
    # calendar date), retaining all source event IDs for traceability.
    key = ["longitude", "latitude", "event_year", "event_month", "event_day"]
    rows["source_record_ids"] = rows.groupby(key, dropna=False).event_id.transform(lambda s: ";".join(sorted(set(s))))
    rows = rows.drop_duplicates(key, keep="first").reset_index(drop=True)
    gdf = gpd.GeoDataFrame(rows, geometry=gpd.points_from_xy(rows.longitude, rows.latitude), crs="EPSG:4326")
    states = gpd.read_file(BOUNDARY)[["shapeName", "geometry"]]
    match = gpd.sjoin(gdf, states, how="left", predicate="within")
    if match.shapeName.isna().any():
        raise ValueError("At least one GFLD record does not fall inside an NER state polygon")
    return match.drop(columns=["index_right"]).rename(columns={"shapeName": "state"})


def raster_value(path: Path, x: float, y: float) -> float:
    with rasterio.open(path) as ds:
        v = next(ds.sample([(x, y)], masked=True))[0]
        if np.ma.is_masked(v):
            return float("nan")
        val = float(v)
        return val if math.isfinite(val) else float("nan")


def static_features(points: gpd.GeoDataFrame) -> pd.DataFrame:
    """Sample only licensed static predictors; no Copernicus DEM is read."""
    wc_paths = sorted(WC_DIR.glob("*.tif"))
    soil_paths = {
        "clay_fraction": next(SOIL_DIR.glob("SoilGrids2_clay_0-5cm_Q0.5_*.tif")),
        "soil_ph": next(SOIL_DIR.glob("SoilGrids2_phh2o_0-5cm_Q0.5_*.tif")),
        "sand_fraction": next(SOIL_DIR.glob("SoilGrids2_sand_0-5cm_Q0.5_*.tif")),
        "soc_stock_t_ha": next(SOIL_DIR.glob("SoilGrids2_soc_0-5cm_Q0.5_*.tif")),
    }
    out = []
    for row in points.itertuples():
        x, y = row.longitude, row.latitude
        wc = float("nan")
        for p in wc_paths:
            with rasterio.open(p) as ds:
                if ds.bounds.left <= x < ds.bounds.right and ds.bounds.bottom < y <= ds.bounds.top:
                    wc = raster_value(p, x, y)
                    break
        soil_raw = {k: raster_value(p, x, y) for k, p in soil_paths.items()}
        # SoilGrids WCS encodings documented in the local acquisition report:
        # clay/sand are per mille, and pH is stored multiplied by ten.
        if soil_raw["soil_ph"] > 140 or soil_raw["soil_ph"] <= 0:
            # A zero encoded pH cannot represent a valid soil pH. The regional
            # WCS TIFF has no nodata tag, so treat the entire coincident all-zero
            # soil vector as missing rather than interpreting it as soil.
            soil_raw = {name: float("nan") for name in soil_raw}
        if soil_raw["clay_fraction"] > 1000 or soil_raw["sand_fraction"] > 1000:
            soil_raw["clay_fraction"] = float("nan")
            soil_raw["sand_fraction"] = float("nan")
        out.append({
            "worldcover_class": int(wc) if math.isfinite(wc) and wc > 0 else np.nan,
            "clay_fraction": soil_raw["clay_fraction"] / 1000 if math.isfinite(soil_raw["clay_fraction"]) else np.nan,
            "sand_fraction": soil_raw["sand_fraction"] / 1000 if math.isfinite(soil_raw["sand_fraction"]) else np.nan,
            "soil_ph": soil_raw["soil_ph"] / 10 if math.isfinite(soil_raw["soil_ph"]) else np.nan,
            "soc_stock_t_ha": soil_raw["soc_stock_t_ha"],
        })
    return pd.DataFrame(out, index=points.index)


def sample_background(events: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Draw within-state unknown backgrounds, at least 10 km from known points."""
    rng = random.Random(SEED)
    states = gpd.read_file(BOUNDARY)[["shapeName", "geometry"]].to_crs("EPSG:6933")
    state_shapes = dict(zip(states.shapeName, states.geometry))
    all_positive = events.to_crs("EPSG:6933").geometry.tolist()
    all_background = []
    rows = []
    for ev in events.itertuples():
        poly = state_shapes[ev.state]
        xmin, ymin, xmax, ymax = poly.bounds
        candidates = []
        attempts = 0
        while len(candidates) < BACKGROUND_PER_EVENT and attempts < 200_000:
            attempts += 1
            px, py = rng.uniform(xmin, xmax), rng.uniform(ymin, ymax)
            p_metric = Point(px, py)
            if not poly.contains(p_metric):
                continue
            if any(p_metric.distance(ep) < MIN_BACKGROUND_DISTANCE_KM * 1000 for ep in all_positive):
                continue
            if any(p_metric.distance(old) < 1000 for old in all_background):
                continue
            candidates.append(p_metric)
        if len(candidates) < BACKGROUND_PER_EVENT:
            raise RuntimeError(f"Could not sample background in state {ev.state}")
        all_background.extend(candidates)
        converted = gpd.GeoSeries(candidates, crs="EPSG:6933").to_crs("EPSG:4326")
        for j, geom in enumerate(converted):
            rows.append({"event_id": f"BG_{ev.event_id}_{j+1}", "source_event_id": ev.event_id,
                         "state": ev.state, "longitude": geom.x, "latitude": geom.y,
                         "event_year": ev.event_year, "event_month": ev.event_month,
                         "event_day": ev.event_day, "label": 0,
                         "source_record_ids": "",
                         "sample_type": "sampled background; landslide status unknown",
                         "source_layer_file": "constructed background; not observed event"})
    result = pd.DataFrame(rows)
    return gpd.GeoDataFrame(result, geometry=gpd.points_from_xy(result.longitude, result.latitude), crs="EPSG:4326")


def make_preprocessor() -> ColumnTransformer:
    return ColumnTransformer([
        ("numeric", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), NUM),
        ("landcover", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                                ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), CAT),
    ], remainder="drop", verbose_feature_names_out=False)


def main() -> None:
    random.seed(SEED)
    np.random.seed(SEED)
    events = read_events()
    if len(events) < 50:
        raise RuntimeError(f"Only {len(events)} usable source events; refusing model run")
    events = events.copy()
    events["label"] = 1
    events["sample_type"] = "GFLD recorded fatal landslide event (centroid point)"
    background = sample_background(events)
    combined = pd.concat([events, background], ignore_index=True)
    combined = gpd.GeoDataFrame(combined, geometry="geometry", crs="EPSG:4326")
    feats = static_features(combined)
    combined = pd.concat([combined.reset_index(drop=True), feats.reset_index(drop=True)], axis=1)
    missing_counts = combined[FEATURES].isna().sum().to_dict()
    missing_fraction = combined[FEATURES].isna().mean().to_dict()
    # Land-cover class is required; missing soil values are imputed by the
    # fitted median imputer so those otherwise valid observations are retained.
    excluded_no_landcover = combined.loc[combined["worldcover_class"].isna(), "event_id"].astype(str).tolist()
    combined = combined.dropna(subset=CAT).reset_index(drop=True)
    if combined.label.nunique() != 2 or combined.label.value_counts().min() < 40:
        raise RuntimeError(f"Insufficient complete samples after raster coverage filtering: {combined.label.value_counts().to_dict()}")
    # Source ID and coordinates are retained for provenance but never predictors.
    X, y = combined[FEATURES], combined.label.astype(int)
    metric = combined.to_crs("EPSG:6933")
    mx = metric.geometry.x.to_numpy()
    my = metric.geometry.y.to_numpy()
    groups = (np.floor(mx / BLOCK_SIZE_M).astype(int).astype(str) + "_" +
              np.floor(my / BLOCK_SIZE_M).astype(int).astype(str))
    n_groups = len(np.unique(groups))
    if n_groups < N_SPLITS:
        raise RuntimeError(f"Only {n_groups} spatial blocks; cannot do {N_SPLITS}-fold grouped validation")
    outer_cv = StratifiedGroupKFold(n_splits=N_SPLITS, shuffle=True, random_state=SEED)
    outer_splits = list(outer_cv.split(X, y, groups))
    candidates = [
        {"n_estimators": 250, "max_depth": None, "min_samples_leaf": 1, "max_features": "sqrt"},
        {"n_estimators": 250, "max_depth": None, "min_samples_leaf": 3, "max_features": "sqrt"},
        {"n_estimators": 250, "max_depth": 12, "min_samples_leaf": 5, "max_features": 0.8},
    ]
    # Nested spatial CV: inner grouped folds select a configuration using only
    # the outer-training area; outer-test predictions are held out from tuning.
    oof_probability = np.full(len(y), np.nan)
    outer_rows = []
    outer_configs = []
    for fold, (outer_train, outer_test) in enumerate(outer_splits, 1):
        if y.iloc[outer_test].nunique() != 2:
            raise RuntimeError(f"Outer spatial fold {fold} contains only one class")
        inner_cv = StratifiedGroupKFold(n_splits=3, shuffle=True, random_state=SEED + fold)
        inner_splits = list(inner_cv.split(X.iloc[outer_train], y.iloc[outer_train], groups[outer_train]))
        inner_scores = []
        for config in candidates:
            scores = []
            for inner_train_rel, inner_valid_rel in inner_splits:
                inner_train = outer_train[inner_train_rel]
                inner_valid = outer_train[inner_valid_rel]
                if y.iloc[inner_valid].nunique() != 2:
                    raise RuntimeError(f"Nested inner fold in outer fold {fold} lacks a class")
                pre_inner = make_preprocessor()
                Xi_tr = pre_inner.fit_transform(X.iloc[inner_train])
                Xi_va = pre_inner.transform(X.iloc[inner_valid])
                clf_inner = RandomForestClassifier(**config, class_weight="balanced_subsample",
                                                   random_state=SEED + fold, n_jobs=-1)
                clf_inner.fit(Xi_tr, y.iloc[inner_train])
                scores.append(float(average_precision_score(y.iloc[inner_valid], clf_inner.predict_proba(Xi_va)[:, 1])))
            inner_scores.append({"config": config, "mean_average_precision": float(np.mean(scores)),
                                 "fold_average_precision": scores})
        chosen = max(inner_scores, key=lambda x: x["mean_average_precision"])
        config = chosen["config"]
        outer_configs.append(config)
        pre_outer = make_preprocessor()
        Xo_tr = pre_outer.fit_transform(X.iloc[outer_train])
        Xo_te = pre_outer.transform(X.iloc[outer_test])
        clf_outer = RandomForestClassifier(**config, class_weight="balanced_subsample",
                                           random_state=SEED + 10_000 + fold, n_jobs=-1)
        clf_outer.fit(Xo_tr, y.iloc[outer_train])
        p = clf_outer.predict_proba(Xo_te)[:, 1]
        oof_probability[outer_test] = p
        yy = y.iloc[outer_test]
        outer_rows.append({"fold": fold, "n_test": int(len(outer_test)),
                           "events": int((yy == 1).sum()), "background_unknown": int((yy == 0).sum()),
                           "roc_auc": float(roc_auc_score(yy, p)),
                           "average_precision": float(average_precision_score(yy, p)),
                           "precision_at_0_5": float(precision_score(yy, p >= .5, zero_division=0)),
                           "recall_at_0_5": float(recall_score(yy, p >= .5, zero_division=0)),
                           "f1_at_0_5": float(f1_score(yy, p >= .5, zero_division=0)),
                           "selected_inner_config": config,
                           "inner_config_scores": inner_scores,
                           "spatial_blocks": sorted(set(groups[outer_test]))})

    if np.isnan(oof_probability).any():
        raise RuntimeError("Nested spatial validation did not generate a prediction for every row")

    # Independently tune final hyperparameters across all available groups;
    # outer CV results above remain untouched by this final refit selection.
    final_cv = StratifiedGroupKFold(n_splits=N_SPLITS, shuffle=True, random_state=SEED + 100)
    final_splits = list(final_cv.split(X, y, groups))
    final_tuning = []
    for config in candidates:
        scores = []
        for train_idx, valid_idx in final_splits:
            pre_tune = make_preprocessor()
            Xtr = pre_tune.fit_transform(X.iloc[train_idx])
            Xva = pre_tune.transform(X.iloc[valid_idx])
            model_tune = RandomForestClassifier(**config, class_weight="balanced_subsample",
                                                random_state=SEED + 101, n_jobs=-1)
            model_tune.fit(Xtr, y.iloc[train_idx])
            scores.append(float(average_precision_score(y.iloc[valid_idx], model_tune.predict_proba(Xva)[:, 1])))
        final_tuning.append({"config": config, "mean_average_precision": float(np.mean(scores)),
                             "fold_average_precision": scores})
    best = max(final_tuning, key=lambda x: x["mean_average_precision"])
    best_probability = oof_probability
    oof_pred = (best_probability >= .5).astype(int)
    cm = confusion_matrix(y, oof_pred, labels=[0, 1])

    # Final artifact: preprocessing and Random Forest are stored separately.
    pre = make_preprocessor()
    Xt = pre.fit_transform(X)
    names = [str(n) for n in pre.get_feature_names_out()]
    model = RandomForestClassifier(**best["config"], class_weight="balanced_subsample",
                                   random_state=SEED, n_jobs=-1)
    model.fit(Xt, y)
    fit_probability = model.predict_proba(Xt)[:, 1]
    fit_label = (fit_probability >= .5).astype(int)
    training_fit_metrics = {"roc_auc": float(roc_auc_score(y, fit_probability)),
                            "average_precision": float(average_precision_score(y, fit_probability)),
                            "precision_at_0_5": float(precision_score(y, fit_label, zero_division=0)),
                            "recall_at_0_5": float(recall_score(y, fit_label, zero_division=0)),
                            "f1_at_0_5": float(f1_score(y, fit_label, zero_division=0))}
    joblib.dump(model, OUT / "ashtaraksha_random_forest.joblib")
    joblib.dump(pre, OUT / "preprocessing_pipeline.joblib")
    (OUT / "feature_list.json").write_text(json.dumps({"raw_features": FEATURES,
        "transformed_features": names, "units": {"worldcover_class": "categorical WorldCover code",
        "clay_fraction": "fraction (SoilGrids per mille / 1000)", "sand_fraction": "fraction (per mille / 1000)",
        "soil_ph": "pH (stored pH x 10, divided by 10)", "soc_stock_t_ha": "tonnes/hectare"}}, indent=2), encoding="utf-8")
    export_cols = ["event_id", "source_record_ids", "source_event_id", "source_layer_file", "state", "longitude", "latitude",
                   "event_year", "event_month", "event_day", "fatalities", "country", "label", "sample_type"] + FEATURES
    combined[export_cols].to_csv(OUT / "training_dataset.csv", index=False, encoding="utf-8")

    fig, ax = plt.subplots(figsize=(9, 6))
    order = np.argsort(model.feature_importances_)
    ax.barh(np.array(names)[order], model.feature_importances_[order], color="#287271")
    ax.set_xlabel("Random Forest impurity importance")
    ax.set_title("Exploratory feature importance (training fit; interpret cautiously)")
    fig.tight_layout(); fig.savefig(OUT / "feature_importance.png", dpi=180); plt.close(fig)
    fig, ax = plt.subplots(figsize=(5.5, 5))
    ConfusionMatrixDisplay(cm, display_labels=["Sampled background\n(unknown outcome)", "GFLD event"]).plot(ax=ax, cmap="Blues", colorbar=False, values_format="d")
    ax.set_title("Spatial OOF confusion matrix (threshold 0.5)", fontsize=11)
    fig.tight_layout(); fig.savefig(OUT / "confusion_matrix.png", dpi=180, bbox_inches="tight"); plt.close(fig)
    metadata = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "status": "trained exploratory presence-background Random Forest",
        "study_region": "North Eastern Region of India; eight state polygons",
        "positive_source": "Global Fatal Landslide Database (GFLD), University of Sheffield; 2017 release; OGL v2.0",
        "positive_source_url": "https://blogs.agu.org/landslideblog/2019/06/18/global-fatal-landslide-database-1/",
        "citation": "Froude and Petley (2018), NHESS 18, 2161–2181, DOI 10.5194/nhess-18-2161-2018",
        "positive_count_used": int((y == 1).sum()), "background_count_used": int((y == 0).sum()),
        "exact_coordinate_date_duplicates_collapsed": int(sum(len(s.split(";"))-1 for s in events.source_record_ids if isinstance(s, str) and s)),
        "missing_features_before_imputation": {k: int(v) for k, v in missing_counts.items()},
        "missing_fraction_before_imputation": {k: float(v) for k, v in missing_fraction.items()},
        "records_excluded_for_missing_worldcover": excluded_no_landcover,
        "imputation": "median for four soil continuous features; most-frequent for categorical land-cover; missing soil vector inferred when encoded pH is zero, since downloaded WCS TIFF lacks a nodata tag",
        "background_definition": "random within-state points at least 10 km from source points; unknown outcome, not confirmed non-landslide",
        "positive_coordinate_caveat": "GFLD point service provides centroids but no per-record positional-accuracy field; pixel samples may be spatially displaced",
        "predictor_sources": [
            {"name": "ESA WorldCover 2021 v200", "license": "CC BY 4.0", "citation": "Zanaga et al. (2022), DOI 10.5281/zenodo.7254221", "attribution": "© ESA WorldCover project 2021 / Contains modified Copernicus Sentinel data (2021) processed by ESA WorldCover consortium"},
            {"name": "ISRIC SoilGrids 2.0", "license": "CC BY 4.0", "citation": "Poggio et al. (2021), DOI 10.5194/soil-7-217-2021", "attribution": "ISRIC – World Soil Information; SoilGrids 2.0"}],
        "excluded": {"CHIRPS": "Not used in this model because the local ClimateSERV files do not prove an exact product-version marker and event-matched background rainfall was not built.",
                     "Copernicus DEM": "Not read; user-personal licence acceptance gate remains unmet.",
                     "NASA GLC CSV": "Excluded; reuse rights unresolved."},
        "validation": {"method": "Nested spatial CV: 5 outer StratifiedGroupKFold folds; each outer training fold tunes 3 configurations with 3 inner grouped folds; groups are 100 km EPSG:6933 grid cells",
                       "outer_folds": outer_rows,
                       "final_tuning_results_across_all_data_for_refit_only": final_tuning,
                       "selected_config_by_mean_average_precision": best["config"],
                       "oof_roc_auc": float(roc_auc_score(y, best_probability)),
                       "oof_average_precision": float(average_precision_score(y, best_probability)),
                       "oof_precision_at_0_5": float(precision_score(y, oof_pred, zero_division=0)),
                       "oof_recall_at_0_5": float(recall_score(y, oof_pred, zero_division=0)),
                       "oof_f1_at_0_5": float(f1_score(y, oof_pred, zero_division=0)),
                       "confusion_matrix_labels_rows_cols": ["background_unknown", "GFLD_event"], "confusion_matrix": cm.tolist(),
                       "final_training_fit_metrics_not_generalization_estimates": training_fit_metrics},
        "training_seed": SEED,
        "intended_use": "exploratory relative presence-background discrimination only; not calibrated probabilities or an operational warning model",
    }
    (OUT / "model_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    (OUT / "model_evaluation_report.md").write_text(render_report(metadata, combined), encoding="utf-8")
    print(json.dumps({"used_samples": combined.label.value_counts().to_dict(),
                      "source_event_ids_after_duplicate_collapse": int(events.source_record_ids.map(lambda s: len(s.split(';')) if isinstance(s,str) and s else 0).sum()),
                      "unique_event_locations_after_duplicate_collapse": len(events),
                      "state_event_counts": events.state.value_counts().to_dict(),
                      "missing_before_imputation": {k: int(v) for k, v in missing_counts.items()},
                      "selected_config": best["config"],
                      "oof_roc_auc": metadata["validation"]["oof_roc_auc"],
                      "oof_average_precision": metadata["validation"]["oof_average_precision"],
                      "oof_precision": metadata["validation"]["oof_precision_at_0_5"],
                      "oof_recall": metadata["validation"]["oof_recall_at_0_5"],
                      "oof_f1": metadata["validation"]["oof_f1_at_0_5"],
                      "confusion_matrix": cm.tolist()}, indent=2))


def render_report(m: dict, df: gpd.GeoDataFrame) -> str:
    v = m["validation"]
    lines = ["# Exploratory Random Forest evaluation", "",
        "## Result", "",
        "A RandomForestClassifier was fitted using real GFLD fatal-event points and sampled background locations. The output is an exploratory presence-background susceptibility experiment, not a calibrated probability map, confirmed absence classifier, or operational warning model.", "",
        f"- GFLD event points used: {m['positive_count_used']} (source OGL v2.0; dates in 2004–2016).",
        f"- Exact coordinate-and-date duplicate records collapsed before sampling: {m['exact_coordinate_date_duplicates_collapsed']}.",
        f"- Sampled background locations used: {m['background_count_used']} (outcome unknown; sampled within the same state and at least {MIN_BACKGROUND_DISTANCE_KM:g} km from reported event points).",
        f"- Training rows after required land-cover coverage: {len(df)}; predictors: {', '.join(FEATURES)}.",
        f"- Missing predictor values before imputation: {json.dumps(m['missing_features_before_imputation'], ensure_ascii=False)}. Missing soil vectors inferred from zero pH were imputed by median; missing land cover records were excluded: {len(m['records_excluded_for_missing_worldcover'])}.",
        f"- Spatial validation: nested {N_SPLITS}-fold outer evaluation; hyperparameters are selected inside each outer-training set using 3 grouped inner folds. Groups use {BLOCK_SIZE_M/1000:.0f} km EPSG:6933 grid cells.",
        f"- Selected parameters: `{json.dumps(v['selected_config_by_mean_average_precision'])}` (selected from three predeclared configurations by mean fold average precision).", "",
        "## Spatial out-of-fold results", "",
        f"- ROC-AUC: {v['oof_roc_auc']:.3f}", f"- Average precision: {v['oof_average_precision']:.3f}",
        f"- Precision at threshold 0.5: {v['oof_precision_at_0_5']:.3f}",
        f"- Recall at threshold 0.5: {v['oof_recall_at_0_5']:.3f}", f"- F1 at threshold 0.5: {v['oof_f1_at_0_5']:.3f}",
        f"- Confusion matrix (rows actual background-unknown/event; columns predicted background-unknown/event): `{v['confusion_matrix']}`.", "",
        f"In-sample fit metrics (not generalization estimates): ROC-AUC {v['final_training_fit_metrics_not_generalization_estimates']['roc_auc']:.3f}; average precision {v['final_training_fit_metrics_not_generalization_estimates']['average_precision']:.3f}; F1 {v['final_training_fit_metrics_not_generalization_estimates']['f1_at_0_5']:.3f}. The difference from outer-fold metrics shows how strongly the forest fits its training sample; use only outer-fold results to describe generalization, with the remaining design caveats.", "",
        "Metrics measure discrimination between the reported fatal-event sample and this particular sampled-background design. The balanced 1:1 sample changes class prevalence; precision, threshold metrics, and scores must not be interpreted as real-world event probability or population performance.", "",
        "## Predictors and sources", "",
        "- ESA WorldCover 2021 v200: land-cover class, CC BY 4.0; use attribution and citation in `model_metadata.json`.",
        "- SoilGrids 2.0: 0–5 cm median clay, sand, pH and soil organic-carbon stock, CC BY 4.0; units were converted as described in `feature_list.json`.",
        "- CHIRPS was excluded because the local legacy ClimateSERV export does not itself establish product version and event-matched background rainfall was not prepared.",
        "- Copernicus DEM was excluded because the user-personal acceptance condition for its licence has not been recorded. NASA GLC records were excluded because reuse rights remain unresolved.", "",
        "## Limitations", "",
        "1. GFLD is a fatality-focused, report-derived sample, not a complete inventory of all landslides. This creates reporting, fatality, and event-selection bias.",
        "2. The public GFLD point service has no per-record location-accuracy field; its points are representative centroids derived from source reports/uncertainty areas. The original uncertainty geometries are not included. Sampling 10 m land-cover and 250 m soil rasters at these centroids may associate events with the wrong local terrain.",
        "3. Backgrounds are not verified non-landslide sites. They are an explicit, reproducible comparison sample and can include unreported landslides.",
        "4. Some SoilGrids pixels had encoded pH=0 and all four properties encoded as zero, but no nodata tag. Those soil values were conservatively treated as missing and median-imputed; the missingness is not described by the original raster metadata.",
        "5. The spatial folds are within the same eight-state region; they do not provide independent temporal validation and do not remove GFLD reporting bias or location error.",
        "6. Only five available static predictor layers were used. No slope, aspect, geology, drainage, or event-conditioned rainfall was included. The model does not establish causal effects.",
        "7. A 2021 land-cover map is temporally later than many 2004–2016 events.",
        "8. Feature importance is model-specific and should not be interpreted causally.", "",
        "## Appropriate use", "",
        "Use only as a hackathon demonstration of a reproducible modeling workflow. Do not represent the score as a validated NER susceptibility probability or an early-warning forecast. Before serious use, obtain GFLD uncertainty geometries or a well-located NER inventory, add licensed terrain and event-date rainfall predictors, test alternative background designs, and conduct independent spatial/temporal validation.", "",
        "The GFLD, WorldCover, and SoilGrids citations and attribution are recorded in `model_metadata.json`."]
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    main()
