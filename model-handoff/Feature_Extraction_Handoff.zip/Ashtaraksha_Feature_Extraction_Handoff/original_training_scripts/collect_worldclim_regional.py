"""Extract regional WorldClim 2.1 BIO rainfall and SRTM-derived elevation.

Only selected TIFF members are read through GDAL's HTTP-range ZIP virtual
filesystem. No global ZIP/TIFF source is saved. Local outputs are NER-clipped
GeoTIFFs and a point feature table for the unchanged V1 observations.
WorldClim data are for academic/non-commercial use only; do not redistribute.
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from rasterio.features import geometry_mask
from rasterio.windows import Window

ROOT = Path(__file__).resolve().parents[2]
V2 = Path(__file__).resolve().parent
OUT = V2 / "data" / "worldclim21_ner"
BOUNDARY = ROOT / "Ashtaraksha_Datasets" / "Rainfall" / "Boundaries" / "NER_8_states.geojson"
TRAINING = ROOT / "Ashtaraksha_Model" / "training_dataset.csv"
BIO_ZIP = "https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_2.5m_bio.zip"
ELEV_ZIP = "https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_30s_elev.zip"
BIO = {12: "annual_precipitation_mm", 13: "wettest_month_precip_mm",
       15: "precipitation_seasonality_pct", 16: "wettest_quarter_precip_mm",
       17: "driest_quarter_precip_mm"}
ATTRIBUTION = "WorldClim 2.1; Fick and Hijmans (2017), International Journal of Climatology 37:4302–4315, DOI 10.1002/joc.5086. Academic/non-commercial use only; do not redistribute raw data."


def read_region(uri: str, bounds: tuple[float, float, float, float], pad: int = 0):
    """Read a source window only, retaining the source grid and masking nodata."""
    with rasterio.Env(CPL_VSIL_CURL_USE_HEAD="NO", GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR",
                      GDAL_HTTP_MAX_RETRY="2", GDAL_HTTP_RETRY_DELAY="5"):
        with rasterio.open(uri) as src:
            if src.crs is None or src.crs.to_epsg() != 4326:
                raise ValueError(f"Expected EPSG:4326, got {src.crs}: {uri}")
            raw_window = src.window(*bounds)
            col0 = max(0, math.floor(raw_window.col_off) - pad)
            row0 = max(0, math.floor(raw_window.row_off) - pad)
            col1 = min(src.width, math.ceil(raw_window.col_off + raw_window.width) + pad)
            row1 = min(src.height, math.ceil(raw_window.row_off + raw_window.height) + pad)
            win = Window(col0, row0, col1 - col0, row1 - row0)
            data = src.read(1, window=win, masked=True).astype("float32")
            meta = {"source_uri": uri, "source_width": src.width, "source_height": src.height,
                    "crs": src.crs.to_string(), "resolution_degrees": list(src.res),
                    "source_nodata": src.nodata, "source_bounds": list(src.bounds),
                    "regional_window": [col0, row0, int(win.width), int(win.height)],
                    "transform": list(src.window_transform(win))[:6],
                    "valid_pixel_count": int(np.count_nonzero(~np.ma.getmaskarray(data)))}
            return data.filled(np.nan), src.window_transform(win), meta


def save_single_band(path: Path, array: np.ndarray, transform, crs: str,
                     name: str, tags: dict, nodata: float = -9999.0) -> None:
    arr = np.asarray(array, dtype="float32")
    profile = {"driver": "GTiff", "width": arr.shape[1], "height": arr.shape[0],
               "count": 1, "dtype": "float32", "crs": crs, "transform": transform,
               "nodata": nodata, "compress": "deflate", "predictor": 3, "tiled": True,
               "blockxsize": 256, "blockysize": 256}
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(np.where(np.isfinite(arr), arr, nodata), 1)
        dst.set_band_description(1, name)
        dst.update_tags(attribution=ATTRIBUTION, **{k: str(v) for k, v in tags.items()})
    with rasterio.open(path) as check:
        if check.count != 1 or check.width != arr.shape[1] or check.height != arr.shape[0]:
            raise IOError(f"Output verification failed: {path}")
        check.read(1, masked=True)


def terrain_features(dem: np.ndarray, transform) -> dict[str, np.ndarray]:
    valid = np.isfinite(dem)
    if valid.sum() < dem.size * 0.98:
        raise ValueError(f"Too many missing elevation cells in regional window: {valid.mean():.3%} valid")
    z = dem.astype("float64")
    if not valid.all():
        # Fill isolated source nodata cells only for gradient calculation. The
        # original validity mask is reapplied to all output terrain predictors.
        from scipy.ndimage import distance_transform_edt
        nearest = distance_transform_edt(~valid, return_distances=False, return_indices=True)
        z[~valid] = z[tuple(nearest[:, ~valid])]
    dz_dcol = np.gradient(z, axis=1)
    dz_drow_south = np.gradient(z, axis=0)
    rows = np.arange(z.shape[0], dtype="float64")
    lat = transform.f + (rows + 0.5) * transform.e
    dx = 111320.0 * np.cos(np.deg2rad(lat)) * abs(transform.a)
    dy = np.full_like(lat, 110574.0 * abs(transform.e))
    dz_dx = dz_dcol / dx[:, None]
    dz_dy_south = dz_drow_south / dy[:, None]
    slope = np.degrees(np.arctan(np.hypot(dz_dx, dz_dy_south)))
    # Downslope azimuth clockwise from north; rows increase toward the south.
    aspect = (np.degrees(np.arctan2(-dz_dx, dz_dy_south)) + 360.0) % 360.0
    flat = slope < 0.1
    aspect[flat] = np.nan
    out = {"elevation_m": z.astype("float32"), "slope_degrees": slope.astype("float32"),
           "aspect_degrees": aspect.astype("float32"),
           "aspect_sin": np.sin(np.deg2rad(aspect)).astype("float32"),
           "aspect_cos": np.cos(np.deg2rad(aspect)).astype("float32")}
    for a in out.values():
        a[~valid] = np.nan
    return out


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    manifest_path = OUT / "worldclim21_regional_manifest.json"
    cached_table = OUT / "worldclim21_environmental_features_by_record.csv"
    expected_paths = ([OUT / f"worldclim21_bio{n}_1970_2000_NER.tif" for n in BIO] +
                      [OUT / f"worldclim21_30s_{name}_NER.tif" for name in
                       ("elevation_m", "slope_degrees", "aspect_degrees", "aspect_sin", "aspect_cos")])
    if manifest_path.is_file() and cached_table.is_file() and all(p.is_file() for p in expected_paths):
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        if existing.get("status") == "complete":
            for path in expected_paths:
                with rasterio.open(path) as ds:
                    if ds.count != 1 or ds.crs is None or ds.width < 1 or ds.height < 1:
                        raise IOError(f"Cached regional raster failed integrity check: {path}")
                    ds.read(1, window=Window(0, 0, min(16, ds.width), min(16, ds.height)), masked=True)
            cached = pd.read_csv(cached_table, dtype={"event_id": str})
            if len(cached) != existing.get("observations", {}).get("rows") or cached.event_id.duplicated().any():
                raise IOError("Cached WorldClim feature table failed row/ID verification")
            print(json.dumps({"status": "already_complete", **existing["observations"]}, indent=2, ensure_ascii=True), flush=True)
            return
    boundary = gpd.read_file(BOUNDARY).to_crs("EPSG:4326")
    if len(boundary) != 8:
        raise ValueError(f"Expected eight state boundary features, got {len(boundary)}")
    bounds = tuple(boundary.total_bounds)
    geom = list(boundary.geometry)
    metadata = {"dataset": "WorldClim v2.1", "baseline": "1970–2000", "license": "Academic and other non-commercial use only; no redistribution or commercial use without prior permission", "attribution": ATTRIBUTION, "boundary_file": str(BOUNDARY.relative_to(ROOT)), "boundary_bounds_wsen": list(bounds), "state_count": len(boundary), "global_zip_saved": False, "regional_outputs": [], "observations": {}}

    # BIO precipitation indices on the official 2.5 arc-minute grid (~4.6 km).
    for number, feature_name in BIO.items():
        member = f"wc2.1_2.5m_bio_{number}.tif"
        uri = f"/vsizip//vsicurl/{BIO_ZIP}/{member}"
        arr, transform, srcmeta = read_region(uri, bounds)
        mask = geometry_mask(geom, out_shape=arr.shape, transform=transform, invert=True)
        arr[~mask] = np.nan
        name = f"bio{number}_{feature_name}"
        path = OUT / f"worldclim21_bio{number}_1970_2000_NER.tif"
        save_single_band(path, arr, transform, "EPSG:4326", name,
                         {"baseline": "1970-2000", "units": "mm" if number != 15 else "% coefficient of variation", "source_version": "WorldClim 2.1", "source_member": member})
        metadata["regional_outputs"].append({"path": str(path.relative_to(V2)), "feature": name,
            "units": "mm" if number != 15 else "% coefficient of variation", "baseline": "1970-2000", **srcmeta})
        print(f"Saved regional BIO{number}: {path.name}", flush=True)

    # SRTM-derived WorldClim 30-arc-second (~1 km), a permitted alternative to
    # credentialed NASA downloads. Read only the NER bounding window.
    elev_uri = f"/vsizip//vsicurl/{ELEV_ZIP}/wc2.1_30s_elev.tif"
    dem, elev_transform, elev_meta = read_region(elev_uri, bounds, pad=2)
    terrain = terrain_features(dem, elev_transform)
    terrain_mask = geometry_mask(geom, out_shape=dem.shape, transform=elev_transform, invert=True)
    for name, arr in terrain.items():
        arr[~terrain_mask] = np.nan
        path = OUT / f"worldclim21_30s_{name}_NER.tif"
        save_single_band(path, arr, elev_transform, "EPSG:4326", name,
                         {"source_version": "WorldClim 2.1 elevation reference surface derived from SRTM", "resolution": "30 arc-seconds (~1 km)", "derivation": "slope/aspect computed from elevation using local geographic pixel dimensions"})
        metadata["regional_outputs"].append({"path": str(path.relative_to(V2)), "feature": name,
            "units": "m" if name == "elevation_m" else ("degrees" if name in {"slope_degrees", "aspect_degrees"} else "unitless"),
            "resolution": "30 arc-seconds (~1 km)", **elev_meta})
        print(f"Saved regional terrain: {path.name}", flush=True)

    # Attach raster-derived features to every unchanged V1 observation.
    training = pd.read_csv(TRAINING, dtype={"event_id": str, "source_event_id": str, "source_record_ids": str})
    points = list(zip(training.longitude.astype(float), training.latitude.astype(float)))
    feature_cols = [f"bio{n}_{BIO[n]}" for n in BIO] + list(terrain)
    feature_arrays: dict[str, np.ndarray] = {}
    for entry in metadata["regional_outputs"]:
        with rasterio.open(V2 / entry["path"]) as ds:
            vals = np.ma.stack([v[0] for v in ds.sample(points, masked=True)]).astype("float64").filled(np.nan)
            vals[~np.isfinite(vals)] = np.nan
            vals[vals == -9999] = np.nan
            feature_arrays[entry["feature"]] = vals
    for column in feature_cols:
        training[column] = feature_arrays[column]
    training["observation_type"] = np.where(training.label.eq(1), "GFLD event; recorded fatal landslide", "sampled background; landslide status unknown")
    training["coordinate_uncertainty"] = np.where(training.label.eq(1), "GFLD point; record-level precision/uncertainty geometry unavailable", "sampled background coordinate; outcome unknown")
    training["worldclim_precip_source"] = "WorldClim 2.1 BIO; 1970-2000; 2.5 arc-minute; academic/non-commercial"
    training["worldclim_terrain_source"] = "WorldClim 2.1 elevation reference surface derived from SRTM; 30 arc-second (~1 km)"
    training["extraction_date_utc"] = datetime.now(timezone.utc).date().isoformat()
    training["rainfall_missing_reason"] = np.where(training[[f"bio{n}_{BIO[n]}" for n in BIO]].isna().any(axis=1), "outside valid raster cells or source NoData", "")
    training["terrain_missing_reason"] = np.where(training[["elevation_m", "slope_degrees", "aspect_sin", "aspect_cos"]].isna().any(axis=1), "source NoData or undefined aspect on flat terrain", "")
    csv_path = OUT / "worldclim21_environmental_features_by_record.csv"
    training.to_csv(csv_path, index=False)
    metadata["observations"] = {"rows": len(training), "positive_events": int(training.label.eq(1).sum()), "unknown_background": int(training.label.eq(0).sum()), "states": sorted(training.state.unique().tolist()), "samples_by_state": {str(state): int(n) for state, n in training.groupby("state").size().items()}, "missing_by_feature": {c: int(training[c].isna().sum()) for c in feature_cols}, "feature_table": str(csv_path.relative_to(V2)), "all_state_coverage": training.state.nunique() == 8}
    metadata["status"] = "complete"
    metadata["updated_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    manifest_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(metadata["observations"], indent=2, ensure_ascii=True), flush=True)


if __name__ == "__main__":
    main()
