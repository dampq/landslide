"""Train and evaluate the separate Version 2 presence-background model.

The data rows/labels and 100 km spatial folds are held identical to V1.
Preprocessing is fitted inside each validation fold. The V1 fitted model is
never opened, changed, or retrained; only its saved OOF metrics/folds are read.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (ConfusionMatrixDisplay, average_precision_score,
                             confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parents[2]
V1_DIR = ROOT / "Ashtaraksha_Model"
V2_DIR = Path(__file__).resolve().parent
V1_DATA = V1_DIR / "training_dataset.csv"
V1_META = V1_DIR / "model_metadata.json"
ENV_TABLE = V2_DIR / "data" / "worldclim21_ner" / "worldclim21_environmental_features_by_record.csv"
BOUNDARY = ROOT / "Ashtaraksha_Datasets" / "Rainfall" / "Boundaries" / "NER_8_states.geojson"
# Match V1's spatial fold seed so the outer block assignments are comparable.
SEED = 20261111
BLOCK_M = 100_000.0
WORLDCLIM_BIO = ["bio12_annual_precipitation_mm", "bio13_wettest_month_precip_mm",
                 "bio15_precipitation_seasonality_pct", "bio16_wettest_quarter_precip_mm",
                 "bio17_driest_quarter_precip_mm"]
MODEL_TERRAIN = ["elevation_m", "slope_degrees", "aspect_sin", "aspect_cos"]
RAW_FEATURES = ["worldcover_class", "clay_fraction", "sand_fraction", "soil_ph", "soc_stock_t_ha",
                *WORLDCLIM_BIO, *MODEL_TERRAIN]
CAT = ["worldcover_class"]
NUM = [c for c in RAW_FEATURES if c not in CAT]
CANDIDATES = [
    {"n_estimators": 250, "max_depth": None, "min_samples_leaf": 1, "max_features": "sqrt"},
    {"n_estimators": 250, "max_depth": None, "min_samples_leaf": 3, "max_features": "sqrt"},
    {"n_estimators": 250, "max_depth": 12, "min_samples_leaf": 5, "max_features": 0.8},
]


def make_preprocessor() -> ColumnTransformer:
    return ColumnTransformer([
        ("numeric", Pipeline([("imputer", SimpleImputer(strategy="median")),
                               ("scale", StandardScaler())]), NUM),
        ("landcover", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                                ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), CAT),
    ], remainder="drop", verbose_feature_names_out=False)


def build_training_table() -> pd.DataFrame:
    if not V1_DATA.is_file() or not ENV_TABLE.is_file():
        raise FileNotFoundError("Need the unchanged Version 1 training CSV and verified WorldClim regional feature table")
    v1 = pd.read_csv(V1_DATA, dtype={"event_id": str, "source_event_id": str, "source_record_ids": str})
    env = pd.read_csv(ENV_TABLE, dtype={"event_id": str, "source_event_id": str, "source_record_ids": str})
    if v1.event_id.duplicated().any() or env.event_id.duplicated().any():
        raise ValueError("Training IDs must be unique")
    if set(v1.event_id) != set(env.event_id):
        raise ValueError("WorldClim extraction does not match the unchanged Version 1 observation IDs exactly")
    for column in ["label", "state", "longitude", "latitude"]:
        if column in env and not env.set_index("event_id").loc[v1.event_id, column].reset_index(drop=True).equals(v1[column].reset_index(drop=True)):
            raise ValueError(f"WorldClim table changed source observation field {column}")
    add = ["event_id", *WORLDCLIM_BIO, *MODEL_TERRAIN, "aspect_degrees", "coordinate_uncertainty",
           "worldclim_precip_source", "worldclim_terrain_source", "extraction_date_utc",
           "rainfall_missing_reason", "terrain_missing_reason"]
    missing_columns = sorted(set(add) - set(env.columns))
    if missing_columns:
        raise ValueError(f"WorldClim table is missing fields: {missing_columns}")
    df = v1.merge(env[add], on="event_id", how="left", validate="one_to_one", sort=False)
    df["observation_type"] = np.where(df.label.eq(1), "GFLD recorded fatal landslide event",
                                     "sampled background; landslide status unknown")
    df["rainfall_source_version"] = "WorldClim 2.1 BIO, 1970-2000 climate normals; 2.5 arc-minute (~4.6 km)"
    df["terrain_source_version"] = "WorldClim 2.1 elevation reference surface derived from SRTM; 30 arc-second (~1 km)"
    df["aspect_feature_encoding"] = "aspect_sin/aspect_cos; raw aspect degrees retained for reporting but excluded from model due circularity"
    return df


def get_groups(df: pd.DataFrame) -> np.ndarray:
    import geopandas as gpd
    points = gpd.GeoDataFrame(df[["longitude", "latitude"]].copy(),
        geometry=gpd.points_from_xy(df.longitude, df.latitude), crs="EPSG:4326").to_crs("EPSG:6933")
    return (np.floor(points.geometry.x.to_numpy() / BLOCK_M).astype(int).astype(str) + "_" +
            np.floor(points.geometry.y.to_numpy() / BLOCK_M).astype(int).astype(str))


def score_config(X: pd.DataFrame, y: pd.Series, groups: np.ndarray, splits: list,
                 config: dict, seed: int) -> list[float]:
    scores = []
    for train_idx, valid_idx in splits:
        pre = make_preprocessor()
        x_train = pre.fit_transform(X.iloc[train_idx])
        x_valid = pre.transform(X.iloc[valid_idx])
        clf = RandomForestClassifier(**config, class_weight="balanced_subsample",
                                     random_state=seed, n_jobs=-1)
        clf.fit(x_train, y.iloc[train_idx])
        scores.append(float(average_precision_score(y.iloc[valid_idx], clf.predict_proba(x_valid)[:, 1])))
    return scores


def main() -> None:
    df = build_training_table()
    class_counts = {int(k): int(v) for k, v in df.label.value_counts().items()}
    if class_counts != {1: 179, 0: 179} or len(df) != 358:
        raise ValueError(f"Expected unchanged 179 GFLD events and 179 unknown backgrounds; got {class_counts}")
    if df.event_id.duplicated().any() or df.loc[df.label.eq(1), "source_record_ids"].isna().any():
        raise ValueError("Duplicate sample IDs or missing GFLD provenance IDs")
    if df.state.nunique() != 8:
        raise ValueError(f"Expected samples across all eight NER states, got {df.state.nunique()}")
    missing_counts = df[RAW_FEATURES].isna().sum().to_dict()
    if df["worldcover_class"].isna().any():
        raise ValueError("WorldCover is missing for observations; refusing to remove or synthesize those records")

    y = df.label.astype(int).reset_index(drop=True)
    X = df[RAW_FEATURES].reset_index(drop=True)
    groups = get_groups(df)
    if len(np.unique(groups)) < 5:
        raise ValueError("Fewer than five spatial groups; cannot run the configured grouped validation")
    outer_splits = list(StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED).split(X, y, groups))
    v1meta = json.loads(V1_META.read_text(encoding="utf-8"))
    v1_folds = [fold["spatial_blocks"] for fold in v1meta["validation"]["outer_folds"]]
    v2_folds = [sorted(set(groups[test])) for _, test in outer_splits]
    if v1_folds != v2_folds:
        raise RuntimeError("V2 outer groups differ from V1 folds; refusing a misleading same-fold comparison")

    oof = np.full(len(y), np.nan, dtype="float64")
    outer_rows = []
    for fold_no, (outer_train, outer_test) in enumerate(outer_splits, 1):
        if y.iloc[outer_train].nunique() < 2 or y.iloc[outer_test].nunique() < 2:
            raise RuntimeError(f"Spatial fold {fold_no} does not contain both labels")
        inner_splits = list(StratifiedGroupKFold(n_splits=3, shuffle=True,
                           random_state=SEED + fold_no).split(X.iloc[outer_train],
                           y.iloc[outer_train], groups[outer_train]))
        tuned = []
        x_inner = X.iloc[outer_train].reset_index(drop=True)
        y_inner = y.iloc[outer_train].reset_index(drop=True)
        g_inner = groups[outer_train]
        for config in CANDIDATES:
            scores = score_config(x_inner, y_inner, g_inner, inner_splits, config, SEED + fold_no)
            tuned.append({"config": config, "fold_average_precision": scores, "mean_average_precision": float(np.mean(scores))})
        best = max(tuned, key=lambda item: item["mean_average_precision"])["config"]
        pre = make_preprocessor()
        xtr = pre.fit_transform(X.iloc[outer_train])
        xte = pre.transform(X.iloc[outer_test])
        model = RandomForestClassifier(**best, class_weight="balanced_subsample",
            random_state=SEED + 10_000 + fold_no, n_jobs=-1)
        model.fit(xtr, y.iloc[outer_train])
        probability = model.predict_proba(xte)[:, 1]
        oof[outer_test] = probability
        predicted = probability >= 0.5
        outer_rows.append({"fold": fold_no, "test_rows": int(len(outer_test)),
            "event_rows": int((y.iloc[outer_test] == 1).sum()),
            "unknown_background_rows": int((y.iloc[outer_test] == 0).sum()),
            "spatial_blocks": v2_folds[fold_no-1], "selected_config": best, "inner_tuning": tuned,
            "roc_auc": float(roc_auc_score(y.iloc[outer_test], probability)),
            "average_precision": float(average_precision_score(y.iloc[outer_test], probability)),
            "precision_at_0_5": float(precision_score(y.iloc[outer_test], predicted, zero_division=0)),
            "recall_at_0_5": float(recall_score(y.iloc[outer_test], predicted, zero_division=0)),
            "f1_at_0_5": float(f1_score(y.iloc[outer_test], predicted, zero_division=0))})
    if not np.isfinite(oof).all():
        raise RuntimeError("Missing nested spatial out-of-fold prediction(s)")

    final_splits = list(StratifiedGroupKFold(n_splits=5, shuffle=True,
                        random_state=SEED + 100).split(X, y, groups))
    final_tuning = []
    for config in CANDIDATES:
        scores = score_config(X, y, groups, final_splits, config, SEED + 101)
        final_tuning.append({"config": config, "fold_average_precision": scores,
                             "mean_average_precision": float(np.mean(scores))})
    best_final = max(final_tuning, key=lambda item: item["mean_average_precision"])["config"]
    pre = make_preprocessor()
    x_all = pre.fit_transform(X)
    model = RandomForestClassifier(**best_final, class_weight="balanced_subsample",
                                   random_state=SEED, n_jobs=-1)
    model.fit(x_all, y)
    feature_names = pre.get_feature_names_out().tolist()

    # Persist the final estimator, preprocessor and exact full observation table.
    joblib.dump(model, V2_DIR / "ashtaraksha_random_forest_v2.joblib")
    joblib.dump(pre, V2_DIR / "preprocessing_pipeline_v2.joblib")
    df.to_csv(V2_DIR / "training_dataset_v2.csv", index=False, encoding="utf-8")
    units = {"worldcover_class":"ESA WorldCover 2021 v200 code",
        "clay_fraction":"fraction (SoilGrids per mille / 1000)", "sand_fraction":"fraction (per mille / 1000)",
        "soil_ph":"pH in water", "soc_stock_t_ha":"tonnes/hectare",
        "bio12_annual_precipitation_mm":"mm/year, WorldClim BIO 1970-2000",
        "bio13_wettest_month_precip_mm":"mm/month, 1970-2000 normal",
        "bio15_precipitation_seasonality_pct":"percent coefficient of variation, 1970-2000",
        "bio16_wettest_quarter_precip_mm":"mm/quarter, 1970-2000 normal",
        "bio17_driest_quarter_precip_mm":"mm/quarter, 1970-2000 normal",
        "elevation_m":"metres above sea level, ~1 km WorldClim 30 arc-second grid",
        "slope_degrees":"degrees, derived from ~1 km elevation grid",
        "aspect_sin":"unitless; sine of aspect azimuth", "aspect_cos":"unitless; cosine of aspect azimuth"}
    schema = {"raw_features": RAW_FEATURES, "categorical_features": CAT,
              "numeric_features": NUM, "transformed_features": feature_names, "units": units,
              "missing_value_policy":"null is accepted for continuous fields and imputed using training-fold medians; WorldCover uses training-fold most-frequent category"}
    (V2_DIR / "feature_list_v2.json").write_text(json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8")

    oof_class = (oof >= 0.5).astype(int)
    cm = confusion_matrix(y, oof_class, labels=[0, 1])
    summary = {"oof_roc_auc": float(roc_auc_score(y, oof)),
        "oof_average_precision": float(average_precision_score(y, oof)),
        "oof_precision_at_0_5": float(precision_score(y, oof_class, zero_division=0)),
        "oof_recall_at_0_5": float(recall_score(y, oof_class, zero_division=0)),
        "oof_f1_at_0_5": float(f1_score(y, oof_class, zero_division=0)), "confusion_matrix": cm.tolist()}
    metadata = {"created_utc":datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "model_version":"2", "status":"trained exploratory static presence-background susceptibility model",
        "study_region":"North Eastern Region of India; all eight named states represented",
        "sample_count":{"GFLD_positive_occurrences":179,"unknown_background":179,"total":len(df)},
        "sample_count_by_state":{str(state):int(n) for state,n in df.groupby("state").size().items()},
        "sample_ids_match_v1":True,"background_label_semantics":"label 0 is sampled background with unknown landslide status, never a confirmed non-landslide observation",
        "positive_inventory":{"name":"Global Fatal Landslide Database NER point subset", "period":"2004-2016",
            "license":"Open Government Licence v2.0", "attribution":"University of Sheffield; cite Froude and Petley (2018), NHESS 18, 2161-2181, DOI 10.5194/nhess-18-2161-2018",
            "source_id_audit":"182 distinct source Total_numb IDs referenced across 179 positive rows were matched to the local six-layer GeoJSON subset; three exact coordinate/date duplicate occurrences were collapsed",
            "location_uncertainty":"per-record positional precision/uncertainty geometry absent; points may not locate initiation sites"},
        "predictors":[
            {"name":"ESA WorldCover 2021 v200","license":"CC BY 4.0","attribution":"© ESA WorldCover project 2021 / Contains modified Copernicus Sentinel data (2021) processed by ESA WorldCover consortium","citation":"Zanaga et al. (2022), DOI 10.5281/zenodo.7254221"},
            {"name":"ISRIC SoilGrids 2.0, 0-5 cm","license":"CC BY 4.0","attribution":"ISRIC – World Soil Information","citation":"Poggio et al. (2021), DOI 10.5194/soil-7-217-2021"},
            {"name":"WorldClim 2.1 BIO12/13/15/16/17","baseline":"1970-2000","resolution":"2.5 arc-minute (~4.6 km)","license":"academic and non-commercial use only; no redistribution or commercial use without permission","attribution":"WorldClim 2.1; Fick and Hijmans (2017), DOI 10.1002/joc.5086","source":"https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_2.5m_bio.zip"},
            {"name":"WorldClim 2.1 elevation reference surface derived from SRTM","resolution":"30 arc-seconds (~1 km)","license":"academic and non-commercial use only; no redistribution or commercial use without permission","attribution":"WorldClim 2.1; Fick and Hijmans (2017), DOI 10.1002/joc.5086","source":"https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_30s_elev.zip","derived_features":["slope_degrees","aspect_degrees","aspect_sin","aspect_cos"]}],
        "rainfall_temporal_interpretation":"BIO features are 1970-2000 climate normals, not event-date or antecedent rainfall; no trigger model is trained",
        "missing_values_before_imputation":{k:int(v) for k,v in missing_counts.items()},
        "missing_data_notes":{"WorldClim BIO":"4 background sample points have source NoData for all five BIO layers; rows retained and training-fold median imputation is used","terrain_aspect":"41 rows are flat or near-flat at ~1 km grid; aspect direction undefined, sine/cosine are null and imputed within folds","soil":"preserves the 49 missing soil values from V1"},
        "feature_count":{"raw":len(RAW_FEATURES),"transformed":len(feature_names)},
        "top_features_by_impurity_importance":[{"name":feature_names[i],"importance":float(model.feature_importances_[i])} for i in np.argsort(model.feature_importances_)[::-1][:8]],
        "validation":{"method":"Nested spatial 5-fold StratifiedGroupKFold; 3 inner grouped folds; 100 km EPSG:6933 blocks; same outer spatial block sets and rows as V1",
            "seed":SEED,"same_outer_folds_as_v1":True,"outer_folds":outer_rows,"final_refit_tuning":final_tuning,
            "selected_final_config":best_final,**summary,"confusion_matrix_labels":["background_unknown","GFLD_event"]},
        "v1_comparison":{"v1_oof_metrics_are_saved_original_results":True,"v1_model_was_not_loaded_or_retrained":True,
            "v1_metrics":{k:float(v1meta["validation"][k]) for k in ("oof_roc_auc","oof_average_precision","oof_precision_at_0_5","oof_recall_at_0_5","oof_f1_at_0_5")}},
        "intended_use":"experimental relative presence-background susceptibility score; not a calibrated probability, NER-validated operational risk map, or early-warning forecast",
        "commercial_use_note":"WorldClim-derived predictor data are academic/non-commercial only; seek prior WorldClim permission before any commercial use or public data redistribution"}
    (V2_DIR / "model_metadata_v2.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")

    fig, ax = plt.subplots(figsize=(10, 7))
    order = np.argsort(model.feature_importances_)
    ax.barh(np.asarray(feature_names)[order], model.feature_importances_[order], color="#287271")
    ax.set_xlabel("Random Forest impurity importance (training fit; descriptive only)")
    ax.set_title("Ashtaraksha Version 2 feature importance")
    fig.tight_layout(); fig.savefig(V2_DIR / "feature_importance_v2.png", dpi=180); plt.close(fig)
    fig, ax = plt.subplots(figsize=(6, 5))
    ConfusionMatrixDisplay(cm, display_labels=["Background\n(outcome unknown)", "GFLD event"]).plot(
        ax=ax, cmap="Blues", colorbar=False, values_format="d")
    ax.set_title("Version 2 spatial out-of-fold confusion matrix")
    fig.tight_layout(); fig.savefig(V2_DIR / "confusion_matrix_v2.png", dpi=180, bbox_inches="tight"); plt.close(fig)

    (V2_DIR / "model_evaluation_report_v2.md").write_text(render_evaluation(metadata), encoding="utf-8")
    (V2_DIR / "model_comparison_report.md").write_text(render_comparison(metadata), encoding="utf-8")
    (V2_DIR / "PROJECT_DEMONSTRATION_REPORT.md").write_text(render_demo(metadata), encoding="utf-8")
    print(json.dumps({"status":"trained", "samples":metadata["sample_count"],
        "raw_features":len(RAW_FEATURES), "transformed_features":len(feature_names), **summary}, indent=2), flush=True)


def render_evaluation(m: dict) -> str:
    v = m["validation"]
    v1 = m["v1_comparison"]["v1_metrics"]
    def fmt(x): return f"{x:.3f}"
    return f"""# Version 2 model evaluation

## Model and data

This separate `RandomForestClassifier` used {m['sample_count']['GFLD_positive_occurrences']} GFLD-reported fatal landslide occurrences and {m['sample_count']['unknown_background']} sampled background locations with unknown outcome. The same rows, source IDs and 100 km outer spatial blocks were used for V1 and V2. V1 was not retrained. V2 uses {m['feature_count']['raw']} raw predictors ({m['feature_count']['transformed']} after categorical encoding): WorldCover, four SoilGrids properties, five WorldClim 2.1 precipitation normals and four terrain encodings (elevation, slope, aspect sine/cosine). Raw aspect degrees are kept in the CSV but excluded from model input because azimuth is circular.

All missing-value imputation is fitted within each training fold (median for continuous inputs, most frequent for WorldCover). No rows were removed for missing environmental values. Four background rows have missing WorldClim BIO cells; 41 rows have undefined aspect direction on flat/near-flat terrain; 49 rows retain V1's missing soil vector.

## Nested spatial out-of-fold performance

| Metric | Version 1 | Version 2 | Change |
|---|---:|---:|---:|
| ROC-AUC | {fmt(v1['oof_roc_auc'])} | {fmt(v['oof_roc_auc'])} | {v['oof_roc_auc']-v1['oof_roc_auc']:+.3f} |
| Average precision | {fmt(v1['oof_average_precision'])} | {fmt(v['oof_average_precision'])} | {v['oof_average_precision']-v1['oof_average_precision']:+.3f} |
| Precision at 0.5 | {fmt(v1['oof_precision_at_0_5'])} | {fmt(v['oof_precision_at_0_5'])} | {v['oof_precision_at_0_5']-v1['oof_precision_at_0_5']:+.3f} |
| Recall at 0.5 | {fmt(v1['oof_recall_at_0_5'])} | {fmt(v['oof_recall_at_0_5'])} | {v['oof_recall_at_0_5']-v1['oof_recall_at_0_5']:+.3f} |
| F1 at 0.5 | {fmt(v1['oof_f1_at_0_5'])} | {fmt(v['oof_f1_at_0_5'])} | {v['oof_f1_at_0_5']-v1['oof_f1_at_0_5']:+.3f} |

Version 2 confusion matrix (`actual rows: background unknown, GFLD event; predicted columns in same order`): `{v['confusion_matrix']}`. The matched-fold results show whether the added data helped this particular sampled design; they do not establish population-level prediction performance. See `model_comparison_report.md` for the interpretation of changes.

## Important limits

- The label 0 records are background samples with unknown landslide status; they are not true negatives. With a 1:1 case/background sample, precision and scores are not calibrated real-world probabilities.
- GFLD is fatality/reporting-biased; event points lack record-specific positional uncertainty geometries. Raster values may not describe the initiation site.
- WorldClim precipitation predictors are 1970–2000 climate normals at ~4.6 km, not daily rainfall before events. This is a static susceptibility experiment, not a trigger or early-warning model.
- The elevation surface is WorldClim's SRTM-derived 30 arc-second (~1 km) product. Slope/aspect at that resolution smooth local hillslope terrain and are not equivalent to 30 m SRTM measurements.
- WorldCover 2021 is later than many 2004–2016 events; SoilGrids are modelled predictions. No independent temporal or external validation was done.
- WorldClim is restricted to academic/non-commercial use and its data may not be redistributed or used commercially without prior permission. Do not publish raw source rasters or derived raster values without checking permission.
- Feature importance is impurity-based and descriptive, not causal.
"""


def render_comparison(m: dict) -> str:
    v1, v2 = m["v1_comparison"]["v1_metrics"], m["validation"]
    names = [("ROC-AUC","oof_roc_auc","oof_roc_auc"),
             ("Average precision","oof_average_precision","oof_average_precision"),
             ("Precision at 0.5","oof_precision_at_0_5","oof_precision_at_0_5"),
             ("Recall at 0.5","oof_recall_at_0_5","oof_recall_at_0_5"),
             ("F1 at 0.5","oof_f1_at_0_5","oof_f1_at_0_5")]
    lines = ["# Version 1 versus Version 2", "",
        "This is a matched-observation and matched-outer-fold comparison: both models use the same 179 positive event occurrences, 179 sampled unknown-background rows, and the same saved 100 km block sets. The V1 fitted model was not retrained. V2's imputation/model tuning was performed inside its training folds.", "",
        "| Metric | V1 | V2 | Change |", "|---|---:|---:|---:|"]
    for label, k1, k2 in names:
        a, b = float(v1[k1]), float(v2[k2])
        lines.append(f"| {label} | {a:.3f} | {b:.3f} | {b-a:+.3f} |")
    deltas = {"ROC-AUC":v2["oof_roc_auc"]-v1["oof_roc_auc"],
              "average precision":v2["oof_average_precision"]-v1["oof_average_precision"]}
    if deltas["ROC-AUC"] > 0 and deltas["average precision"] > 0:
        conclusion = "Both ROC-AUC and average precision rose on these matched folds; this is a promising demonstration result, not proof of robust improvement given the small, biased event inventory and unknown backgrounds."
    elif deltas["ROC-AUC"] < 0 and deltas["average precision"] < 0:
        conclusion = "Both ROC-AUC and average precision fell on these matched folds. The added variables did not improve this experiment's spatial generalization; keep V1 as the stronger baseline by these metrics."
    else:
        conclusion = "The discrimination metrics move in different directions; the evidence does not support a blanket claim that V2 is better. Compare the metrics and limitations rather than selecting on one number."
    lines += ["", "## Interpretation", "", conclusion, "",
        "Both models classify recorded GFLD fatal events against a selected sample of locations with unknown outcome. These metrics are not calibrated landslide probabilities and do not measure a real-world false-alarm rate. V2 adds WorldClim 1970–2000 climate normals, ~1 km SRTM-derived terrain and the existing land-cover/soil variables. The WorldClim predictors are academic/non-commercial only; no commercial or public data redistribution is permitted without prior permission.", ""]
    return "\n".join(lines)


def render_demo(m: dict) -> str:
    v = m["validation"]
    top = "; ".join(f"{item['name']} ({item['importance']:.3f})" for item in m["top_features_by_impurity_importance"][:5])
    state_counts = "; ".join(f"{state}: {count}" for state, count in m["sample_count_by_state"].items())
    return f"""# Ashtaraksha Version 2 demonstration

## What it does

Version 2 is an experimental Random Forest that ranks the sampled NER locations by how similar their static environment is to locations of reported fatal landslides in the training sample. It is **not** a real-time alert, a calibrated landslide probability, or a guarantee that a site will or will not fail.

## Data used

- 179 GFLD reported fatal event occurrences as positive records. All 182 distinct source IDs in those rows match the local author-release GeoJSON subset; three duplicate coordinate/date occurrences were collapsed before the original V1 table was made.
- 179 existing sampled background points, explicitly labelled as unknown landslide outcome, not verified negatives.
- ESA WorldCover 2021 v200 class and SoilGrids 2.0 0–5 cm clay, sand, pH and SOC values already used by V1.
- WorldClim 2.1 BIO12, BIO13, BIO15, BIO16 and BIO17 climate characteristics for 1970–2000, at 2.5 arc-minute (~4.6 km). These are long-term climate normals, not measurements taken on landslide dates.
- WorldClim 2.1 SRTM-derived elevation at 30 arc-seconds (~1 km); slope and aspect were derived from this grid. This terrain is much coarser than 30 m hillside terrain.

The observations represent all eight states: Assam, Arunachal Pradesh, Meghalaya, Manipur, Mizoram, Nagaland, Sikkim and Tripura. Exact counts appear in `model_metadata_v2.json`.

Rows by state (events plus unknown-background samples): {state_counts}.

## Data values versus model output

GFLD points are reported fatal events with approximate, record-level-uncertain locations. WorldClim precipitation and SoilGrids are modelled gridded surfaces, not rain-gauge or soil-field readings at each coordinate. WorldCover is a 2021 classification; WorldClim BIO layers are 1970–2000 normals; elevation is a ~1 km remote-sensing-derived surface. The model's score is a prediction from those inputs, not another environmental measurement. No simulated rainfall, event, label or website score is included in the training set. The API example in `README.md` uses an actual saved row.

## How the features relate to susceptibility

Rainfall normals provide broad wetness and seasonality context; they do not say how much it rained in the hours or days before an event. Elevation and slope describe broad relief, while aspect sine/cosine encode the direction a slope faces without treating 359° and 1° as far apart. Land cover and modelled soil properties add surface/soil context. These correlations do not establish causation.

The largest training-fit impurity importances were {top}. This describes how the fitted forest used its inputs on this small training sample; it is not evidence of causal influence or robust population importance.

## Evaluation

Matched spatial cross-validation results: ROC-AUC {v['oof_roc_auc']:.3f}; average precision {v['oof_average_precision']:.3f}; precision {v['oof_precision_at_0_5']:.3f}; recall {v['oof_recall_at_0_5']:.3f}; F1 {v['oof_f1_at_0_5']:.3f} at score threshold 0.5. Version 2 versus Version 1 results and changes are in `model_comparison_report.md`. These are within-region grouped estimates for the sampled case/background design, not independent validation or real-world probability estimates.

## Limitations and next development steps

GFLD records are fatality/reporting biased and their exported points have no per-record location precision. Background points can include unreported landslides. The sample is small; 4 background rows have missing BIO values, 41 rows have undefined aspect on flat/near-flat terrain, and 49 retain missing V1 soil values. Fold-local imputation retains those rows. WorldCover is from 2021; rainfall normal is 1970–2000; elevation/slope is about 1 km. Do not present this as an early-warning system or as validated state-wide susceptibility.

For a later research phase, obtain a well-located local inventory and independent event dates, add licensed finer-resolution DEM and antecedent rainfall matched to both event and background times, test alternative background sampling designs, and validate on held-out locations/time periods. WorldClim is academic/non-commercial only: do not redistribute raw data or use commercially without prior permission. Any website demo should label returned values as experimental relative scores; simulated interface examples must be distinguished from actual observed events.

"""


if __name__ == "__main__":
    main()
