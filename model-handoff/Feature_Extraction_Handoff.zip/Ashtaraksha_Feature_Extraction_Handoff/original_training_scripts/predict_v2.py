"""Strict V2 prediction adapter; continuous nulls are imputed and reported."""
from __future__ import annotations
import json
import math
from pathlib import Path

import joblib
import pandas as pd

HERE = Path(__file__).resolve().parent
MODEL = joblib.load(HERE / "ashtaraksha_random_forest_v2.joblib")
PREPROCESSOR = joblib.load(HERE / "preprocessing_pipeline_v2.joblib")
SCHEMA = json.loads((HERE / "feature_list_v2.json").read_text(encoding="utf-8"))
FEATURES = SCHEMA["raw_features"]
# These nine categories were represented in the original fitted V1 land-cover
# schema and therefore are known to be represented in the unchanged samples.
WORLDCOVER_CODES = {10, 30, 40, 50, 60, 70, 80, 90, 100}


def predict_relative_score(record: dict) -> dict:
    if not isinstance(record, dict):
        raise TypeError("Input must be a JSON object")
    missing = sorted(set(FEATURES) - set(record))
    extra = sorted(set(record) - set(FEATURES))
    if missing or extra:
        raise ValueError(f"Input fields mismatch; missing={missing}, extra={extra}")
    code = record["worldcover_class"]
    if isinstance(code, bool) or not isinstance(code, int) or code not in WORLDCOVER_CODES:
        raise ValueError(f"worldcover_class must be one of the categories represented in training: {sorted(WORLDCOVER_CODES)}")
    values = {"worldcover_class": code}
    imputed_fields = []
    for name in FEATURES[1:]:
        value = record[name]
        if value is None:
            values[name] = None
            imputed_fields.append(name)
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{name} must be a finite JSON number or null")
        value = float(value)
        if not math.isfinite(value):
            raise ValueError(f"{name} must be finite")
        values[name] = value
    for name in ("clay_fraction", "sand_fraction"):
        if values[name] is not None and not 0 <= values[name] <= 1:
            raise ValueError(f"{name} must be between 0 and 1")
    if values["soil_ph"] is not None and not 0 <= values["soil_ph"] <= 14:
        raise ValueError("soil_ph must be between 0 and 14")
    for name in ("soc_stock_t_ha", *FEATURES[5:10]):
        if values[name] is not None and values[name] < 0:
            raise ValueError(f"{name} must be nonnegative")
    if values["elevation_m"] is not None and not -500 <= values["elevation_m"] <= 9000:
        raise ValueError("elevation_m must be between -500 and 9000 metres")
    if values["slope_degrees"] is not None and not 0 <= values["slope_degrees"] <= 90:
        raise ValueError("slope_degrees must be between 0 and 90 degrees")
    for name in ("aspect_sin", "aspect_cos"):
        if values[name] is not None and not -1 <= values[name] <= 1:
            raise ValueError(f"{name} must be between -1 and 1")

    frame = pd.DataFrame([{name: values[name] for name in FEATURES}], columns=FEATURES)
    transformed = PREPROCESSOR.transform(frame)
    score = float(MODEL.predict_proba(transformed)[0, 1])
    return {"experimental_presence_background_score": score,
            "interpretation": "Relative score for GFLD recorded fatal events versus sampled locations of unknown outcome; not a calibrated landslide probability or warning.",
            "model_version": "2", "model_region": "North Eastern Region of India; internal spatial validation only",
            "imputed_fields": imputed_fields}
