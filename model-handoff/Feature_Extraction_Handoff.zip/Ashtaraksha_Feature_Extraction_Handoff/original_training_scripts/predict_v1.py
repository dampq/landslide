"""Prediction helper for the experimental presence-background model."""
from pathlib import Path
import joblib
import pandas as pd

HERE = Path(__file__).resolve().parent
PREPROCESSOR = joblib.load(HERE / "preprocessing_pipeline.joblib")
MODEL = joblib.load(HERE / "ashtaraksha_random_forest.joblib")
FEATURES = ["worldcover_class", "clay_fraction", "sand_fraction", "soil_ph", "soc_stock_t_ha"]


def predict_relative_score(record: dict) -> dict:
    """Return experimental relative presence-background score, not event probability."""
    frame = pd.DataFrame([{name: record.get(name) for name in FEATURES}], columns=FEATURES)
    x = PREPROCESSOR.transform(frame)
    score = float(MODEL.predict_proba(x)[0, 1])
    return {"experimental_presence_background_score": score,
            "interpretation": "Relative score against this model's sampled unknown backgrounds; not a calibrated landslide probability or warning.",
            "model_region": "North Eastern Region of India; within-region spatial evaluation",
            "features": frame.iloc[0].to_dict()}


if __name__ == "__main__":
    demo = {"worldcover_class": 30, "clay_fraction": .2, "sand_fraction": .35,
            "soil_ph": 5.2, "soc_stock_t_ha": 25}
    print(predict_relative_score(demo))
