# Coordinate feature extraction guide for the website teammate

## What is verified and what is new

The exact training-side feature definitions and raster samplers were recovered from the original V1 and V2 scripts and checked against the saved feature lists, serialized preprocessing pipelines, model inputs and training tables. Those original scripts are copied into `original_training_scripts/` unchanged.

The module `feature_extraction/coordinate_feature_extractor.py` is a clearly labelled reconstruction for a selected web map coordinate. It applies the recovered raster-sampling and conversion rules, was run against the real project rasters, and reproduced the saved features and model scores for event 467. It was **not** the script used to build the historical training tables. See `reconstructed_scripts/RECONSTRUCTION_NOTES.md`.

## How a selected coordinate becomes model features

1. React sends decimal latitude/longitude and a requested version to the backend.
2. The backend validates numeric ranges and checks the point against the eight-state boundary.
3. It locates the relevant WorldCover tile, then samples the four SoilGrids rasters and, for V2, the five WorldClim BIO rasters plus four terrain grids.
4. Rasterio `DatasetReader.sample(..., masked=True)` reads one pixel at the point. The recovered training code did **not** bilinearly interpolate or average a neighborhood. Training rasters are EPSG:4326 and were passed longitude/latitude directly. The reconstructed adapter can transform coordinates if a deployment raster has another CRS.
5. It converts SoilGrids clay/sand from per mille to fractions and pH × 10 to pH. SOC is already stock in t/ha and is not converted. It returns any missing source value as `null` with a diagnostic; it never fills it with a fabricated environmental value.
6. The version-specific `predict_relative_score()` function sends features through the matching saved preprocessing pipeline and classifier. Keep each model and its pipeline together. Do not manually scale or one-hot encode values before calling the helper.

All sources are local files. The extractor does not call an external raster API. For a deployed backend, configure the local raster paths in `feature_extraction/config.json` and ensure the backend host has access to those raster files. The feature package ZIP does not contain the large rasters or either model; those stay in the existing project/model deployment.

## Raster files required on the backend

With the default project-relative configuration, keep these existing files/folders available:

- Boundary: `Ashtaraksha_Feature_Extraction_Handoff/feature_extraction/data/NER_8_states.geojson` (small boundary copy included in package).
- All 10 tiles in `Ashtaraksha_Datasets/Land_Cover/WorldCover_2021_v200_tiles/`.
- Four files named in `config.json` under `Ashtaraksha_Datasets/Soil_Geology/SoilGrids_2.0_NER/`.
- V2 rasters named in `config.json` under `Ashtaraksha_Model/Version_2/data/worldclim21_ner/`: five BIO layers, elevation, slope, aspect sine and aspect cosine.
- Matching model artifacts and helpers under `Ashtaraksha_Model/` and `Ashtaraksha_Model/Version_2/`.

Do not substitute the project’s Copernicus DEM tiles for V2 terrain. They are not the source used to train this model. V2 uses WorldClim's 30 arc-second (~1 km) elevation reference surface derived from SRTM. WorldClim terms are academic/non-commercial; redistribution or commercial use requires prior permission.

## Exact input schemas

V1 raw features in order: `worldcover_class`, `clay_fraction`, `sand_fraction`, `soil_ph`, `soc_stock_t_ha`.

V2 raw features in order: V1's five followed by `bio12_annual_precipitation_mm`, `bio13_wettest_month_precip_mm`, `bio15_precipitation_seasonality_pct`, `bio16_wettest_quarter_precip_mm`, `bio17_driest_quarter_precip_mm`, `elevation_m`, `slope_degrees`, `aspect_sin`, `aspect_cos`.

The detailed units, data types, source raster names, versions, resolution, NoData rules, depth and conversions are in `V1_feature_specification.json` and `V2_feature_specification.json`. Model values: WorldCover is a category code; clay/sand are 0–1 fractions; pH is pH in water; SOC is tonnes/hectare; BIO12/13/16/17 are precipitation normals in their named time-unit; BIO15 is percent coefficient of variation; elevation is metres; slope is degrees; aspect sine/cosine are unitless.

V2 BIO variables are **1970–2000 climate normals**, not rainfall in the day/week before a landslide. WorldCover is a 2021 classification. SoilGrids are modelled estimates, not field samples. These dates and scales matter when describing website results.

## Use the feature extractor

Install `requirements.txt` in a Python 3.12 environment with Rasterio/GDAL wheels compatible with the host, then from the project root:

```powershell
python Ashtaraksha_Feature_Extraction_Handoff\feature_extraction\coordinate_feature_extractor.py 26.19 91.71
```

Or in Python:

```python
from Ashtaraksha_Feature_Extraction_Handoff.feature_extraction.coordinate_feature_extractor import extract_coordinate

result = extract_coordinate(latitude=26.19, longitude=91.71)
v1_inputs = result["v1_features"]
v2_inputs = result["v2_features"]
```

The module returns coordinate/state, both raw dictionaries, a per-layer `source_status`, a list of missing features and the sampling method. It rejects invalid coordinates and points outside the eight-state boundary. A missing raster file is an error. A valid point with source NoData is returned with `null` for that field; do not silently replace it with zero.

## Call model helpers

With model folders available in the existing project:

```python
from Ashtaraksha_Model.predict import predict_relative_score as predict_v1
from Ashtaraksha_Model.Version_2.predict_v2 import predict_relative_score as predict_v2

v1_result = predict_v1(result["v1_features"])
v2_result = predict_v2(result["v2_features"])
```

V1's helper and fitted pipeline can impute numeric gaps in research code, but the existing strict V1 FastAPI schema requires finite numbers for all five fields. The example coordinate API therefore abstains from V1 scoring if a V1 source value is missing. V2's helper accepts null continuous inputs and reports imputed fields; WorldCover still must be a modelled category. Missing-value imputation belongs to the stored fitted pipeline, not to the feature extraction code.

## Actual reproducible event 467 example

Record `event_id=467` is the GFLD event at latitude `26.19`, longitude `91.71`, Assam. The coordinate extractor was run against the real local rasters. Its 14 raw V2 values were:

```json
{
  "worldcover_class": 10,
  "clay_fraction": 0.199,
  "sand_fraction": 0.367,
  "soil_ph": 5.5,
  "soc_stock_t_ha": 170.0,
  "bio12_annual_precipitation_mm": 1677.0,
  "bio13_wettest_month_precip_mm": 341.0,
  "bio15_precipitation_seasonality_pct": 88.4172134399414,
  "bio16_wettest_quarter_precip_mm": 925.0,
  "bio17_driest_quarter_precip_mm": 33.0,
  "elevation_m": 55.0,
  "slope_degrees": 0.3024371862411499,
  "aspect_sin": -0.5689411163330078,
  "aspect_cos": -0.8223782777786255
}
```

The saved V1 model scores the same row `0.7506392613449581`; the saved V2 model scores it `0.9369784686315531`. These are **in-sample scores for a known training record**, included strictly as a reproducibility check, not an unbiased performance estimate or general-purpose map-coordinate example. Each example JSON also includes the exact transformed input vector and feature order from the serialized pipeline.

For example, the coordinate endpoint accepts these actual requests:

```json
{"latitude": 26.19, "longitude": 91.71, "version": "v1"}
```

```json
{"latitude": 26.19, "longitude": 91.71, "version": "v2"}
```

The V1 response at this location contains the five-feature object shown above and a prediction object with score `0.7506392613449581`, `model_region` set to “North Eastern Region of India; within-region spatial evaluation”, and interpretation “Relative score against this model's sampled unknown backgrounds; not a calibrated landslide probability or warning.” The V2 response contains the fourteen-feature object shown above and prediction score `0.9369784686315531`, `model_version` `2`, `imputed_fields` `[]`, and interpretation “Relative score for GFLD recorded fatal events versus sampled locations of unknown outcome; not a calibrated landslide probability or warning.” Exact raw/transformed response records, including all 22 V2 transformed values, are saved in the two event 467 JSON files.

The original trained pipelines convert numeric values with median imputation and `StandardScaler`; WorldCover is most-frequent imputed and one-hot encoded. Thus V1 has 5 raw and 13 transformed columns, while V2 has 14 raw and 22 transformed columns. The exact transformed order is verified in the feature specification JSON. Let the pipeline perform these transformations; do not apply them twice.

## FastAPI and React connection

The package includes `feature_extraction/fastapi_feature_extraction_example.py`. From project root, a backend developer can run:

```powershell
uvicorn Ashtaraksha_Feature_Extraction_Handoff.feature_extraction.fastapi_feature_extraction_example:app --host 127.0.0.1 --port 8000
```

Example request:

```http
POST /predict-at-coordinate
Content-Type: application/json
```

```json
{"latitude": 26.19, "longitude": 91.71, "version": "v2"}
```

The response includes extracted features and source status plus the score result from the existing V2 predictor. React should call this backend with `fetch`, show an error when the backend responds 4xx/5xx, and display the returned interpretation/limitations with the score. Enable CORS only for the deployed website origin. Do not expose file paths or model binaries to the browser. The full HTTP health/prediction smoke test is **still pending**; helper-level extraction and model checks do not prove HTTP deployment works.

## Errors to show in the frontend

- Invalid coordinate or outside the NER boundary: “This location is outside the supported study area.”
- Missing raster file/service configuration: “Environmental data are temporarily unavailable for this location.”
- Required source pixels missing, especially WorldCover or V1 soil inputs: “A complete feature set is not available here; no score was returned.”
- Unexpected server/model error: generic retry message; log technical diagnostics on the backend only.

Do not message a location as safe just because the model returns a low score. These experimental presence-background models contrast fatal reported events with sampled background points of unknown landslide status. They are not calibrated probabilities, forecasts, official warnings, or independent validation of all NER conditions. V2 had lower matched spatial metrics than V1 and should remain experimental.
