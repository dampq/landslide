# V2 terrain specifications

## Verified elevation source and files

The source is the WorldClim 2.1 elevation reference raster `wc2.1_30s_elev.tif`, obtained from the official elevation ZIP by the recovered `collect_worldclim_regional.py` script. WorldClim describes this as its elevation reference surface derived from SRTM. It is a **30 arc-second (~1 km) surface**, not 30 m SRTM. Regional EPSG:4326 outputs are in `Ashtaraksha_Model/Version_2/data/worldclim21_ner/`:

- `worldclim21_30s_elevation_m_NER.tif` (metres)
- `worldclim21_30s_slope_degrees_NER.tif` (degrees)
- `worldclim21_30s_aspect_degrees_NER.tif` (intermediate/reporting only)
- `worldclim21_30s_aspect_sin_NER.tif` and `worldclim21_30s_aspect_cos_NER.tif` (the aspect inputs used by V2)

Each is 1 band, 1,133 × 908 pixels, EPSG:4326, 0.0083333333° pixels, with NoData `-9999`. The five terrain files reopened and contained valid pixels. Regional output is clipped/masked to the eight-state boundary. The source script reads a padded regional window; it does not reproject the output grid.

## Exact terrain derivation

The script `original_training_scripts/collect_worldclim_regional.py` contains the original code. It uses NumPy `gradient` on elevation in row and column directions. At each row it approximates ground pixel spacing as `dx = 111320 * cos(latitude) * abs(pixel_width_degrees)` and `dy = 110574 * abs(pixel_height_degrees)`. Gradient components are divided by those metre spacings. Slope is `degrees(atan(hypot(dz_dx, dz_dy)))`. Downslope azimuth is `(degrees(atan2(-dz_dx, dz_dy_south)) + 360) % 360`; aspect sine/cosine are computed from that azimuth in radians.

For isolated invalid source cells, the code nearest-fills cells for the gradient calculation only when at least 98% of the regional elevation window is valid, then reapplies the original validity mask to all outputs. Aspect is set missing when calculated slope is `<0.1°`. `aspect_degrees` is retained as a derived intermediate, but the fitted model uses `aspect_sin` and `aspect_cos` to encode circular direction.

The saved regional rasters were sampled at all training points by `Rasterio DatasetReader.sample` (one pixel, no interpolation). No 30 m SRTM tile was used in V2. Although Copernicus DEM tiles exist elsewhere in the project, the saved V2 terrain files and training code do not use them.

## Licence

WorldClim terms permit academic and other non-commercial use; raw data redistribution and commercial use require prior permission. Attribute WorldClim 2.1 and cite Fick and Hijmans (2017), DOI 10.1002/joc.5086. See [WorldClim elevation products](https://www.worldclim.org/data/worldclim21.html) and [terms](https://www.worldclim.org/about.html).
