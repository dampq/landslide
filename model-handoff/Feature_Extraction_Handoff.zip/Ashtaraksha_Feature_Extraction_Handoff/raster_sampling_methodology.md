# Raster sampling methodology: recovered facts

## V1

The original implementation is `original_training_scripts/train_random_forest_v1.py`, copied from the actual V1 training script. `read_events()` loads the local GFLD GeoJSON layers, reads each point's longitude/latitude, deduplicates source IDs and exact coordinate/date repeats, and spatially joins points to the eight-state polygon file. `static_features()` then samples WorldCover and SoilGrids.

`raster_value()` opens the raster with Rasterio and calls `next(ds.sample([(x, y)], masked=True))[0]`. This is a single containing/nearest raster cell sample, not bilinear or cubic interpolation. The script supplies longitude as x and latitude as y directly; it does not reproject coordinates. Local WorldCover/SoilGrids rasters were verified EPSG:4326, so the no-transform method is consistent with those particular inputs. It has no explicit separate edge interpolation. WorldCover selection checks tile bounds before sampling; SoilGrids is sampled directly. Masked/nonfinite samples become NaN. WorldCover nodata is 0 and missing land cover was excluded; soil no-tag semantics use the pH sentinel described in `soilgrids_specifications.md`.

The saved V1 `training_dataset.csv` is the exact feature table consumed by the existing model artifacts. The copied training script documents and implements event/background creation and raster feature extraction, but do not rerun it when you only need inference.

## V2

V2 retained the same 358 IDs and reused the V1 table for the first five inputs. `collect_worldclim_regional.py` reads selected WorldClim raster windows, masks regional rasters by the NER boundary, then samples saved regional raster files for each original longitude/latitude using `ds.sample(points, masked=True)`. All regional output rasters are EPSG:4326; the script rejects a remote source whose CRS is not EPSG:4326. The sample is one source pixel, without resampling/interpolation. No coordinate transformation was performed in the training extraction path.

The V2 training script joins the five rainfall and four terrain values to V1 rows on unique `event_id`, checks that state, labels and coordinates match, then fits the V2 preprocessing pipeline. Raw `aspect_degrees` is stored for audit but excluded; the model consumes aspect sine and cosine.

## Location uncertainty, edges and missing coverage

The GFLD point export does not contain per-record position-accuracy geometry. The scripts neither shift points nor buffer-average pixels; sampled values are simply those at the supplied point. This means positional error may select a different cell than the true initiation location.

When a sample is masked, non-finite, outside a raster extent, or otherwise unavailable, the feature table preserves a missing value rather than substituting zero. V2 has 4 missing BIO rows and 41 missing aspect rows; V1 has 49 rows with the soil vector missing. V2 fitted preprocessing imputes numeric features with training medians. The feature extractor reports these fields and does not make up replacements. Outside the eight-state polygon is rejected. A missing local raster raises `SourceDataUnavailableError`.

## New coordinate module scope

`feature_extraction/coordinate_feature_extractor.py` is explicitly a **reconstruction** of the recovered operations for one web coordinate, not a script used to create the original training CSV. It reproduces those raster methods and conversions, handles general raster CRS by transforming a point if a deployed raster is not EPSG:4326 (the training source rasters are EPSG:4326, so this branch is not needed for parity), and returns nulls plus per-feature source statuses. It was tested against real local inputs and saved training rows. Keep the original scripts as the authoritative provenance for training.
