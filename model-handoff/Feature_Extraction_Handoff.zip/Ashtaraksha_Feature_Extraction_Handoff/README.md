# Ashtaraksha feature extraction handoff

This package helps a website backend turn an NER map coordinate into the raw predictors for the already trained Version 1 and Version 2 Random Forest models. It does not retrain or change either model.

## Contents

- `TEAMMATE_FEATURE_EXTRACTION_GUIDE.md` — deployment and usage guide with real example inputs.
- `feature_extraction/` — configurable coordinate extractor, included NER boundary and illustrative FastAPI route.
- `original_training_scripts/` — copies of the original V1/V2 training, WorldClim extraction and predictor source scripts.
- `reconstructed_scripts/RECONSTRUCTION_NOTES.md` — what the new adapter reconstructs and what it does not claim.
- `V1_feature_specification.json`, `V2_feature_specification.json` — verified schemas, input transformations and ordered columns.
- `dataset_source_manifest.csv` — actual local source layers used by the models and provenance/licence notes.
- `soilgrids_specifications.md`, `terrain_specifications.md`, `raster_sampling_methodology.md`.
- `reproducible_examples/` — event 467 raw and transformed inputs and predictions for each version.
- `test_scripts/test_reproducibility.py` — real-raster/model regression checks.
- `requirements.txt` — observed project runtime versions.
- `FEATURE_EXTRACTION_HANDOFF_AUDIT.md` — audit of verified, reconstructed, assumed and unknown details.

## Data and models expected beside the package

By default, `feature_extraction/config.json` resolves the project root as the package's parent directory. The backend therefore expects the existing `Ashtaraksha_Datasets/` and `Ashtaraksha_Model/` folders beside this handoff folder. Edit the relative paths in `config.json` if deployment layout differs. The package intentionally excludes large rasters, training CSVs and model binaries. Required raster filenames are enumerated in the config and guide.

## Run the tests in the original project folder

```powershell
python -m unittest discover -s Ashtaraksha_Feature_Extraction_Handoff\test_scripts -p test_*.py -v
```

The tests were executed against the actual local rasters and serialized models during package preparation. Full HTTP `/health` and `/predict-at-coordinate` testing in the teammate's deployment environment remains pending.

The project-root ZIP created for delivery is named exactly `frnd.zip`.
