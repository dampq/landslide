# Ashtaraksha feature extraction handoff audit

**Audit date:** 2026-11-13  
**Scope:** Inspect existing V1/V2 training and extraction implementation, recover input schema and provenance, implement and test a coordinate-level handoff reconstruction.  
**No model was trained or modified.** Existing model and pipeline joblibs were only loaded for feature-name and prediction verification.

## Summary

- Original V1 extraction logic was recovered in `Ashtaraksha_Model/train_random_forest.py`: GFLD point preparation, state matching, static raster sampling, soil conversion and the V1 preprocessing/model workflow.
- V2 reuses the V1 environmental values and adds WorldClim BIO12/13/15/16/17 and WorldClim elevation-derived terrain. The original sampling/terrain code is in `Ashtaraksha_Model/Version_2/collect_worldclim_regional.py`; the training-table join and fold-local preprocessing are in `train_random_forest_v2.py`.
- The saved V1 and V2 feature-list JSON files match their serialized preprocessing pipelines' `get_feature_names_out()` exactly: **5 raw → 13 transformed** for V1 and **14 raw → 22 transformed** for V2.
- A separate reconstructed coordinate adapter is included. It sampled the existing real rasters at event 467 and reproduced the stored training-table values and scores: V1 `0.7506392613449581`, V2 `0.9369784686315531`. These are a known training record's in-sample outputs, not independent validation results.
- Seven automated regression tests ran and passed against real project rasters and saved models. Full FastAPI HTTP `/health` and coordinate prediction verification is still pending in the teammate's deployed environment.
- Delivery archive is `frnd.zip` at project root; no alternate ZIP was created for this handoff.

## Verified facts from existing files and execution

1. **V1 raw order:** `worldcover_class`, `clay_fraction`, `sand_fraction`, `soil_ph`, `soc_stock_t_ha`.
2. **V2 raw order:** the V1 five followed by BIO12 annual precipitation, BIO13 wettest month, BIO15 precipitation seasonality, BIO16 wettest quarter, BIO17 driest quarter, elevation, slope, aspect sine and aspect cosine. Raw aspect degrees is not a model input.
3. **Feature transformation:** continuous columns go through median imputation and `StandardScaler`; WorldCover goes through most-frequent imputation and one-hot encoding. The serialized fit supplies the inference transform. The fitted output order is explicitly listed in each feature specification and checked by tests.
4. **Raster sampling:** V1 `raster_value()` and V2 regional extraction call Rasterio `DatasetReader.sample(..., masked=True)` for one pixel. No bilinear/cubic interpolation, neighborhood average, point-buffer aggregation, or location-uncertainty correction appears in the training extraction code. The training inputs are EPSG:4326 and source code passes longitude/latitude directly. The reconstructed adapter optionally transforms if a future deployed raster CRS differs.
5. **Soil properties:** all four are SoilGrids 2.0 Q0.5 median layers at 0–5 cm. Clay and sand are stored in per mille and divided by 1000; pH is stored ×10 and divided by 10. `soc` is Soil organic carbon **stock** in t/ha and is passed without a concentration-to-stock conversion. No GDAL NoData tag exists in the four WCS TIFFs. The original V1 heuristic marks all soil values missing if encoded pH is finite and `<=0` or `>140`; it separately invalidates clay/sand above 1000‰.
6. **Terrain:** V2 uses WorldClim 2.1's SRTM-derived 30 arc-second (~1 km) elevation reference surface, not 30 m SRTM. The actual slope/aspect derivation code uses NumPy gradients, approximate local geographic pixel dimensions, `atan(hypot())`, and the downhill azimuth formula documented in `terrain_specifications.md`. Aspect is null for slope `<0.1°`; output rasters use NoData `-9999`.
7. **WorldClim rainfall:** V2 uses BIO12/13/15/16/17, baseline 1970–2000, 2.5 arc-minute (~4.6 km), regional rasters with NoData `-9999`. These are long-term normals, not event-date or antecedent rainfall. WorldClim is academic/non-commercial under its terms; raw data redistribution and commercial use require prior permission.
8. **Other sources:** WorldCover 2021 v200 uses 10 local Map tiles at 10 m, EPSG:4326, category NoData 0; attribution and CC BY 4.0 are retained. GFLD positive observations use the locally present OGL v2.0 subset and the model table's source IDs. The 8-state GeoJSON is used to select/match study locations, not as an input feature.
9. **Excluded layers:** CHIRPS is not in either saved feature schema or trained input code and is therefore not included as a source manifest input. Copernicus DEM tiles exist in the project but are not read by either trained-model workflow; they are not V2 terrain. The WorldClim source was used instead. NASA GLC-derived records with unresolved reuse rights are not inputs to this training table.

## Exact example validation

The saved training rows identify event 467 at **26.19° N, 91.71° E, Assam**. The coordinate module sampled the real rasters and matched all raw values in the saved table. The saved preprocessing pipelines produced the exact stored 13- and 22-column vectors in `reproducible_examples/event_id_467_v1.json` and `_v2.json`; the saved classifiers reproduced their expected scores to `1e-12`. The V2 score exactly matches `0.9369784686315531`.

Missing values were also tested with real records: event 4177 yields the original all-zero/no-tag SoilGrids missing-vector condition, and saved background record `BG_2833_1` in Sikkim has NoData across the five BIO layers. The adapter returns nulls and source statuses rather than artificial values.

## Reconstructed implementation details

`feature_extraction/coordinate_feature_extractor.py` is newly written glue that combines the verified samplers and conversions for arbitrary points. It was not part of the original training run. It validates finite geographic coordinates, checks that a point is covered by one of the included state polygons, loads raster paths from editable project-relative `config.json`, preserves missing values, and returns both raw schemas and diagnostics. It refuses out-of-region points and missing raster files. The optional FastAPI example is illustrative and has not passed a full HTTP test.

All original training/extraction scripts copied in the handoff package are unmodified copies. `processed/preprocessing_scripts/extract_permitted_features.py` was not used to create either trained feature table; its own header describes it as syntax-checked only, and it implements a different event-day rainfall path. The separate `Ashtaraksha_Model/Version_2/train_random_forest.py` is an earlier CHIRPS-normal workflow; the current saved V2 artifacts and `train_random_forest_v2.py` use WorldClim BIO/terrain, so that legacy script is not represented as current model provenance. The validation-only Colab notebooks are likewise not the source of the trained model tables. These are marked as non-source/unrecovered in reconstruction notes.

## Unknowns and limitations

- No stored historical log proves each past original script execution step; the saved training table, current scripts and data align, and event 467 reproduces, but exact environment/session history is not available.
- SoilGrids WCS rasters have no explicit NoData code, so the original pH sentinel heuristic is the actual implementation but not a perfect authoritative mask. Source metadata does not encode units in TIFF tags; the local WCS inventory/report records the units and conversions.
- The boundary GeoJSON has no explicit CRS member; the project boundary audit treats its coordinates as longitude/latitude (CRS84 convention). Its listed CC BY 2.5 India status and source attribution come from the local inventory; verify source-specific attribution before redistributing boundary geometry.
- Geospatial raster sampling at event points cannot correct for missing GFLD per-record positional uncertainty. V1 strict API requires all five finite values; V2's helper permits null continuous features and relies on its fitted imputers.
- A coordinate outside a raster's extent or landing on source NoData is not assigned a value. The frontend should show an unavailable/unsupported message where model/API constraints require abstention.
- Model outputs are experimental relative presence-background scores, not calibrated probabilities, an official alert, or evidence that a low-score place is safe. V2 scored lower than V1 in their matched spatial evaluation; no independent NER validation exists.

## Verification run for this package

- Parsed both feature JSON files and the CSV source manifest.
- Loaded both saved preprocessing pipelines and classifiers; verified classifier input dimensions 13 and 22, classes `[0,1]`, and exact feature-name order.
- Opened the actual feature raster files through the coordinate adapter at event 467 and compared values with the existing saved training tables.
- Executed `python -m unittest discover -s Ashtaraksha_Feature_Extraction_Handoff/test_scripts -p test_*.py -v`: **7 tests passed** (event 467 raw/prediction reproduction, invalid coordinates, outside NER, missing WorldClim cell, missing SoilGrids vector, missing raster file, and model feature order).
- Compiled 10 Python files without writing bytecode; parsed all 5 JSON files and opened the CSV manifest. The 5 copied original scripts matched their source SHA-256 hashes. The project-root ZIP `frnd.zip` opens successfully, passes CRC integrity, includes the required handoff package and excludes model joblibs, training CSVs and raster files.
- **Not performed:** full HTTP `/health` or `/predict-at-coordinate` request in an actual deployed Uvicorn environment.
