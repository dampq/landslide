"""Coordinate feature extraction tools for the Ashtaraksha models."""
