"""Coordinate-to-feature adapter matching the recovered V1/V2 raster workflow.

Rasterio's DatasetReader.sample is used for pixel sampling, matching the original
training/extraction scripts. It selects the containing/nearest pixel; it does
not interpolate. Paths are configured in config.json relative to the project.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import rasterio
from pyproj import Transformer
from rasterio.errors import RasterioError
from shapely.geometry import Point, shape


HERE = Path(__file__).resolve().parent
PACKAGE_ROOT = HERE.parent
CONFIG = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
PROJECT_ROOT = (PACKAGE_ROOT / CONFIG["project_root_relative_to_package"]).resolve()

V1_FEATURES = ["worldcover_class", "clay_fraction", "sand_fraction", "soil_ph", "soc_stock_t_ha"]
V2_FEATURES = V1_FEATURES + [
    "bio12_annual_precipitation_mm", "bio13_wettest_month_precip_mm",
    "bio15_precipitation_seasonality_pct", "bio16_wettest_quarter_precip_mm",
    "bio17_driest_quarter_precip_mm", "elevation_m", "slope_degrees",
    "aspect_sin", "aspect_cos",
]


class FeatureExtractionError(ValueError):
    """Base error suitable for mapping to an HTTP 4xx/5xx response."""


class InvalidCoordinateError(FeatureExtractionError):
    pass


class UnsupportedLocationError(FeatureExtractionError):
    pass


class SourceDataUnavailableError(FeatureExtractionError):
    pass


def _path(relative: str) -> Path:
    return PROJECT_ROOT / relative


def _finite_coordinate(latitude: Any, longitude: Any) -> tuple[float, float]:
    if isinstance(latitude, bool) or isinstance(longitude, bool):
        raise InvalidCoordinateError("Latitude and longitude must be numeric coordinates.")
    try:
        lat, lon = float(latitude), float(longitude)
    except (TypeError, ValueError) as exc:
        raise InvalidCoordinateError("Latitude and longitude must be numeric coordinates.") from exc
    if not math.isfinite(lat) or not math.isfinite(lon) or not -90 <= lat <= 90 or not -180 <= lon <= 180:
        raise InvalidCoordinateError("Coordinates must be finite decimal degrees within latitude [-90,90], longitude [-180,180].")
    return lat, lon


def _state_for(lon: float, lat: float) -> str:
    boundary_path = _path(CONFIG["boundary"])
    if not boundary_path.is_file():
        raise SourceDataUnavailableError(f"NER boundary file is missing: {boundary_path}")
    doc = json.loads(boundary_path.read_text(encoding="utf-8"))
    point = Point(lon, lat)
    for feature in doc.get("features", []):
        geom = feature.get("geometry")
        if geom and shape(geom).covers(point):
            return str(feature.get("properties", {}).get("shapeName", "NER state"))
    raise UnsupportedLocationError("Coordinate is outside the eight-state NER boundary supported by these models.")


def _sample(path: Path, lon: float, lat: float) -> float | None:
    if not path.is_file():
        raise SourceDataUnavailableError(f"Required raster is missing: {path}")
    try:
        with rasterio.open(path) as ds:
            if ds.crs is None:
                raise SourceDataUnavailableError(f"Raster has no CRS: {path.name}")
            if ds.crs.to_epsg() == 4326:
                x, y = lon, lat
            else:
                transformer = Transformer.from_crs("EPSG:4326", ds.crs, always_xy=True)
                x, y = transformer.transform(lon, lat)
            if not (ds.bounds.left <= x < ds.bounds.right and ds.bounds.bottom <= y < ds.bounds.top):
                return None
            # Match the recovered scripts: Rasterio sample (one source pixel,
            # no bilinear/cubic interpolation) with masked=True.
            value = next(ds.sample([(x, y)], indexes=1, masked=True))[0]
            if np.ma.is_masked(value):
                return None
            value = float(value)
            if not math.isfinite(value) or (ds.nodata is not None and value == ds.nodata):
                return None
            return value
    except RasterioError as exc:
        raise SourceDataUnavailableError(f"Could not read raster {path.name}: {exc}") from exc


def _v1_values(lon: float, lat: float) -> tuple[dict[str, Any], dict[str, str]]:
    worldcover_dir = _path(CONFIG["worldcover_dir"])
    if not worldcover_dir.is_dir():
        raise SourceDataUnavailableError(f"WorldCover tile directory is missing: {worldcover_dir}")
    wc: int | None = None
    wc_status = "OUTSIDE_COLLECTED_TILES"
    for raster_path in sorted(worldcover_dir.glob("*_Map.tif")):
        with rasterio.open(raster_path) as ds:
            if ds.crs is None:
                raise SourceDataUnavailableError(f"WorldCover tile has no CRS: {raster_path.name}")
            x, y = lon, lat
            if ds.crs.to_epsg() != 4326:
                x, y = Transformer.from_crs("EPSG:4326", ds.crs, always_xy=True).transform(lon, lat)
            if ds.bounds.left <= x < ds.bounds.right and ds.bounds.bottom < y <= ds.bounds.top:
                value = _sample(raster_path, lon, lat)
                wc = int(round(value)) if value is not None and value > 0 else None
                wc_status = "OK" if wc is not None else "OUTSIDE_OR_NODATA"
                break
    soil_dir = _path(CONFIG["soilgrids_dir"])
    soil_raw: dict[str, float | None] = {}
    for feature, filename in CONFIG["soil_rasters"].items():
        soil_raw[feature] = _sample(soil_dir / filename, lon, lat)
    ph_raw = soil_raw["soil_ph"]
    # Exact V1 source handling: encoded pH is x10; zero or >140 signals the
    # all-zero untagged vector and invalidates the coincident soil vector.
    if ph_raw is not None and (ph_raw > 140 or ph_raw <= 0):
        soil_raw = {name: None for name in soil_raw}
    for prop in ("clay_fraction", "sand_fraction"):
        if soil_raw[prop] is not None and soil_raw[prop] > 1000:
            soil_raw[prop] = None
    vals = {
        "worldcover_class": wc,
        "clay_fraction": None if soil_raw["clay_fraction"] is None else soil_raw["clay_fraction"] / 1000.0,
        "sand_fraction": None if soil_raw["sand_fraction"] is None else soil_raw["sand_fraction"] / 1000.0,
        "soil_ph": None if soil_raw["soil_ph"] is None else soil_raw["soil_ph"] / 10.0,
        # The selected SoilGrids SOC layer is already stock in t/ha; no
        # concentration-to-stock conversion was performed.
        "soc_stock_t_ha": soil_raw["soc_stock_t_ha"],
    }
    return vals, {"worldcover_class": wc_status, **{k: "OK" if v is not None else "SOURCE_NODATA_OR_OUTSIDE_RASTER" for k, v in vals.items() if k != "worldcover_class"}}


def _v2_values(lon: float, lat: float) -> tuple[dict[str, Any], dict[str, str]]:
    raster_dir = _path(CONFIG["worldclim_dir"])
    if not raster_dir.is_dir():
        raise SourceDataUnavailableError(f"WorldClim regional raster directory is missing: {raster_dir}")
    vals: dict[str, Any] = {}
    status: dict[str, str] = {}
    for feature, filename in CONFIG["worldclim_rasters"].items():
        value = _sample(raster_dir / filename, lon, lat)
        vals[feature] = value
        status[feature] = "OK" if value is not None else "SOURCE_NODATA_OR_OUTSIDE_RASTER"
    return vals, status


def extract_coordinate(latitude: float, longitude: float) -> dict[str, Any]:
    """Return V1/V2 raw features and per-source availability for an NER point.

    Continuous source NoData remains ``None``. No row-level imputation is
    performed here; imputation is part of each saved model's fitted pipeline.
    """
    lat, lon = _finite_coordinate(latitude, longitude)
    state = _state_for(lon, lat)
    v1, v1_status = _v1_values(lon, lat)
    v2_extra, v2_status = _v2_values(lon, lat)
    v2 = {**v1, **v2_extra}
    v1_missing = [key for key in V1_FEATURES if v1[key] is None]
    v2_missing = [key for key in V2_FEATURES if v2[key] is None]
    return {
        "coordinates": {"latitude": lat, "longitude": lon},
        "state": state,
        "v1_features": {key: v1[key] for key in V1_FEATURES},
        "v2_features": {key: v2[key] for key in V2_FEATURES},
        "source_status": {"v1": v1_status, "v2": {**v1_status, **v2_status}},
        "missing_features": {"v1": v1_missing, "v2": v2_missing},
        "sampling_method": "Rasterio DatasetReader.sample, one containing pixel, no interpolation; source grids are sampled in their CRS (training source rasters are EPSG:4326).",
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("latitude", type=float)
    parser.add_argument("longitude", type=float)
    args = parser.parse_args()
    print(json.dumps(extract_coordinate(args.latitude, args.longitude), indent=2, ensure_ascii=True))
