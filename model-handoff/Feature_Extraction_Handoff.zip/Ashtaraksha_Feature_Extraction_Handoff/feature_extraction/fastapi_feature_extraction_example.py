"""Optional backend example: map coordinate -> extracted features -> score.

Run from project root with: uvicorn Ashtaraksha_Feature_Extraction_Handoff.feature_extraction.fastapi_feature_extraction_example:app
The example expects this handoff folder and existing Ashtaraksha_Model folders
to remain in their project-relative locations. HTTP behavior is illustrative;
the full server-level smoke test is still pending.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parent
PROJECT = PACKAGE.parent
MODEL_DIR = PROJECT / "Ashtaraksha_Model"
V2_DIR = MODEL_DIR / "Version_2"
sys.path.insert(0, str(HERE))
from coordinate_feature_extractor import (  # noqa: E402
    FeatureExtractionError, InvalidCoordinateError, SourceDataUnavailableError,
    extract_coordinate,
)


def _load_helper(name: str, script: Path):
    spec = importlib.util.spec_from_file_location(name, script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load inference helper: {script}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


v1 = _load_helper("ashtaraksha_predict_v1_handoff", MODEL_DIR / "predict.py")
v2 = _load_helper("ashtaraksha_predict_v2_handoff", V2_DIR / "predict_v2.py")


class CoordinateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    latitude: float = Field(ge=-90, le=90, allow_inf_nan=False)
    longitude: float = Field(ge=-180, le=180, allow_inf_nan=False)
    version: str = Field(pattern="^(v1|v2)$")


app = FastAPI(title="Ashtaraksha coordinate feature demo", version="0.1")


@app.get("/health")
def health():
    return {"status": "loaded", "feature_extraction": "local configured rasters", "http_smoke_test": "pending deployment verification"}


@app.post("/predict-at-coordinate")
def predict_at_coordinate(request: CoordinateRequest):
    try:
        extracted = extract_coordinate(request.latitude, request.longitude)
    except InvalidCoordinateError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except FeatureExtractionError as exc:
        status = 503 if isinstance(exc, SourceDataUnavailableError) else 422
        raise HTTPException(status_code=status, detail=str(exc)) from exc

    if extracted["v1_features"]["worldcover_class"] is None:
        raise HTTPException(status_code=422, detail={"message": "WorldCover category is unavailable at this coordinate; prediction cannot proceed.", "missing": extracted["missing_features"]})
    result = {"coordinates": extracted["coordinates"], "state": extracted["state"], "features": extracted[f"{request.version}_features"],
              "source_status": extracted["source_status"][request.version], "missing_features": extracted["missing_features"][request.version]}
    if request.version == "v1":
        # Existing strict V1 schema requires finite values for all four soil
        # fields; do not silently change its API contract or fill at request time.
        if extracted["missing_features"]["v1"]:
            raise HTTPException(status_code=422, detail={"message": "Required V1 source data is missing; no score returned.", "missing": extracted["missing_features"]["v1"], "source_status": extracted["source_status"]["v1"]})
        result["prediction"] = v1.predict_relative_score(extracted["v1_features"])
    else:
        result["prediction"] = v2.predict_relative_score(extracted["v2_features"])
    return result
