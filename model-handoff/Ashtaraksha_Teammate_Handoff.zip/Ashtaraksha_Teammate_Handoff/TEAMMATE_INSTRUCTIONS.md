# Ashtaraksha website model handoff

## Recommended website default

Use **Version 1** as the default because it performed better than Version 2 on the matched spatial evaluation. V1 is the simpler model, with five required environmental inputs. Keep **Version 2** available as an explicitly experimental comparison: it adds long-term climate normals and coarse terrain inputs, but its matched evaluation scores were lower. Neither model has independent validation and neither returns a calibrated probability.

## Package contents

- `Version_1_Default/` contains the unchanged V1 model artifacts, prediction helper, strict FastAPI example and project handoff report.
- `Version_2_Experimental/` contains the unchanged V2 model artifacts, prediction helper, FastAPI example, evaluation/comparison reports, plots and pinned requirements.
- The package intentionally excludes training CSVs, source inventories and raster data.

## Environment and loading

Use Python 3.12 and install `Version_2_Experimental/requirements.txt` in a virtual environment. It includes the runtime dependencies used for both model helpers (including joblib, pandas and scikit-learn) plus FastAPI/Pydantic/Uvicorn. Then run the API from the corresponding version folder so the helpers find their sibling model files:

```powershell
cd Version_1_Default
python -m pip install -r ..\Version_2_Experimental\requirements.txt
uvicorn fastapi_example_v1_strict:app --host 127.0.0.1 --port 8000
```

For V2 use `cd Version_2_Experimental` and `uvicorn fastapi_example_v2:app --host 127.0.0.1 --port 8001`.

Direct Python inference is also available:

```python
from predict import predict_relative_score  # run with Version_1_Default as working/import folder
result = predict_relative_score({
    "worldcover_class": 30,
    "clay_fraction": 0.20,
    "sand_fraction": 0.35,
    "soil_ph": 5.2,
    "soc_stock_t_ha": 25.0,
})
```

For V2, import `predict_relative_score` from `predict_v2` in `Version_2_Experimental`. The helper loads `ashtaraksha_random_forest_v2.joblib` and `preprocessing_pipeline_v2.joblib` from its own folder. The equivalent V1 helper loads the two V1 joblibs beside `predict.py`. Keep each model, pipeline, feature list and helper together; do not mix versions.

## Inputs and units

Inputs must be extracted from the environmental layers at the requested location by the website/backend. The model package does not extract features from latitude/longitude.

### V1 required fields

| Field | Meaning and units |
|---|---|
| `worldcover_class` | ESA WorldCover 2021 v200 categorical code. Codes represented in the model: 10, 30, 40, 50, 60, 70, 80, 90, 100. |
| `clay_fraction` | SoilGrids 0–5 cm clay fraction, 0–1 (per-mille source value divided by 1000). |
| `sand_fraction` | SoilGrids 0–5 cm sand fraction, 0–1 (per-mille source value divided by 1000). |
| `soil_ph` | SoilGrids pH in water. |
| `soc_stock_t_ha` | Soil organic-carbon stock, tonnes/hectare. |

The strict V1 API requires every value to be a finite JSON number (WorldCover must be an integer); it rejects unknown/extra fields and invalid WorldCover codes.

### V2 required fields

V2 requires the five V1 fields plus:

| Field | Meaning and units |
|---|---|
| `bio12_annual_precipitation_mm` | Annual precipitation normal, mm/year. |
| `bio13_wettest_month_precip_mm` | Wettest-month precipitation normal, mm/month. |
| `bio15_precipitation_seasonality_pct` | Precipitation seasonality, percent coefficient of variation. |
| `bio16_wettest_quarter_precip_mm` | Wettest-quarter precipitation normal, mm/quarter. |
| `bio17_driest_quarter_precip_mm` | Driest-quarter precipitation normal, mm/quarter. |
| `elevation_m` | Elevation in metres, from approximately 1 km WorldClim 30 arc-second grid. |
| `slope_degrees` | Slope in degrees, derived from that approximately 1 km elevation grid. |
| `aspect_sin`, `aspect_cos` | Unitless sine and cosine of aspect direction. Both may be `null` where aspect is undefined. |

V2's BIO values are WorldClim 1970–2000 long-term climate normals, not rainfall before an event. Continuous V2 fields may be `null`; the saved preprocessing pipeline imputes continuous values with training-fold medians and WorldCover with the training-fold most-frequent class. `predict_v2.py` reports fields it imputed. The API schema still requires each key to be present; use JSON `null` for an unavailable optional continuous feature. Do not send NaN or infinity.

## FastAPI and React integration

Run the selected FastAPI app in a backend service. Keep the model files on that backend; do not bundle joblib files or inference credentials in the React client. React should POST JSON to the backend's `/predict` route. Configure FastAPI CORS with only the deployed website origin before browser calls. Validate the response and display the explanatory interpretation string. Use HTTPS in deployment and keep input feature extraction/versioning consistent with the model metadata.

Example V1 request:

```http
POST /predict
Content-Type: application/json
```

```json
{
  "worldcover_class": 30,
  "clay_fraction": 0.2,
  "sand_fraction": 0.35,
  "soil_ph": 5.2,
  "soc_stock_t_ha": 25.0
}
```

Example response shape (the numeric score depends on the supplied values):

```json
{
  "experimental_presence_background_score": 0.62,
  "interpretation": "Relative score against this model's sampled unknown backgrounds; not a calibrated landslide probability or warning.",
  "model_region": "North Eastern Region of India; within-region spatial evaluation",
  "features": {
    "worldcover_class": 30,
    "clay_fraction": 0.2,
    "sand_fraction": 0.35,
    "soil_ph": 5.2,
    "soc_stock_t_ha": 25.0
  }
}
```

V2 request shape (all fields are required; unavailable BIO/aspect values may be `null`):

```json
{
  "worldcover_class": 30,
  "clay_fraction": 0.2,
  "sand_fraction": 0.35,
  "soil_ph": 5.2,
  "soc_stock_t_ha": 25.0,
  "bio12_annual_precipitation_mm": 2500.0,
  "bio13_wettest_month_precip_mm": 500.0,
  "bio15_precipitation_seasonality_pct": 80.0,
  "bio16_wettest_quarter_precip_mm": 1200.0,
  "bio17_driest_quarter_precip_mm": 100.0,
  "elevation_m": 450.0,
  "slope_degrees": 18.0,
  "aspect_sin": 0.5,
  "aspect_cos": 0.866
}
```

## Limitations and user-facing language

The training set has 179 reported fatal landslide occurrences and 179 sampled background points whose landslide outcome is unknown. The score contrasts those groups; background points are not confirmed safe locations. GFLD events are reporting/fatality biased and their point locations have uncertain positional precision. There is no independent NER validation. Do not describe either output as a probability, forecast, real-time warning, or confirmation that a site is safe.

Suggested display text: **“Experimental relative susceptibility score for research demonstration. It is not a calibrated probability or an official warning. Local conditions and independent validation are not represented.”** For V2 also state that its spatial evaluation was weaker than V1 and that rainfall inputs are 1970–2000 normals.

WorldClim data in V2 is permitted for academic/non-commercial use under its terms; do not redistribute raw WorldClim data or use it commercially without permission. Full HTTP API testing is still pending: helper/schema/prediction checks passed, but the local HTTP health request stalled. Run `/health` and `/predict` smoke tests in the actual deployment environment before connecting the website.
