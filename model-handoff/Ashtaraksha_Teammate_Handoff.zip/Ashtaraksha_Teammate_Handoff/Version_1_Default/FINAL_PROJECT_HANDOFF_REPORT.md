# Ashtaraksha model handoff

Updated: 2026-11-12

## Current result

- **Version 1 remains unchanged** and passed its saved-model, preprocessing, feature order and direct-prediction checks. A real row (`event_id=467`) scored `0.7506392613449581` through both direct inference and V1's helper. All seven preserved artifact hashes still match their pre-V2 fingerprints.
- A separate **Version 2 Random Forest has now been trained and saved**. It uses the same 358 rows (179 GFLD fatal-event occurrences and 179 sampled backgrounds of unknown landslide status) and the same five spatial outer folds as V1.
- V2 adds five WorldClim precipitation climate normals and terrain from WorldClim's SRTM-derived ~1 km elevation surface to the existing WorldCover/SoilGrids inputs. The feature table covers all eight NER states.
- V2 did **not** outperform V1 on matched spatial OOF metrics. Keep V1 as the stronger performance baseline; V2 is a feature-rich but weaker experimental comparison.
- The strict V2 prediction helper and FastAPI schema checks passed directly. TestClient could construct a client but stalled on `GET /health`; an HTTP-level API test is still outstanding.

## V1 verification and serving

V1 loads as a `RandomForestClassifier` with 13 transformed features and classes `[0, 1]`; its preprocessing pipeline takes five raw inputs. The original `predict.py` is permissive about missing/extra/invalid categories, so I added [fastapi_example_v1_strict.py](fastapi_example_v1_strict.py) without modifying V1 files. The strict adapter rejects missing/extra fields, wrong types, unseen categories, NaN and infinity. Teammate should still run an HTTP smoke test in the serving environment. Do not call its response a probability or warning.

The full V1 checks and fingerprints are in [FINAL_MODEL_HANDOFF_REPORT.md](FINAL_MODEL_HANDOFF_REPORT.md). Runtime used for this work: Python 3.12.10, NumPy 2.5.4, pandas 3.1.1, scikit-learn 1.6.1, GeoPandas 1.2.0, Rasterio 1.5.2, SciPy 1.18.1, FastAPI 0.115.8 and Pydantic 2.14.3.

## Training observations and provenance

The GFLD author-release subset is attributed to the University of Sheffield under OGL v2.0; cite Froude and Petley (2018), DOI 10.5194/nhess-18-2161-2018. I checked all 182 distinct `Total_numb` IDs referenced across the 179 V1 positive rows against the six local GeoJSON layers; all matched. Three exact coordinate/date duplicate occurrences had been collapsed in the unchanged V1 training table. The point export lacks per-record location accuracy/uncertainty polygons, so environmental extraction may not represent the landslide initiation site.

Background rows stay labelled as sampled background of **unknown outcome**, not confirmed non-landslides. NASA GLC coordinates with unresolved reuse rights remain excluded. No synthetic event labels or new backgrounds were created for V2.

## Environmental data collected and used

### Existing products reused

- ESA WorldCover 2021 v200 land-cover classes, CC BY 4.0; retain ESA attribution and cite Zanaga et al., DOI 10.5281/zenodo.7254221.
- SoilGrids 2.0 0–5 cm clay, sand, pH and SOC stock, CC BY 4.0; acknowledge ISRIC and cite Poggio et al., DOI 10.5194/soil-7-217-2021.
- Existing V1 observation coordinates, labels and source IDs, preserved exactly.

### WorldClim 2.1 rainfall — obtained

Five NER-clipped regional rasters and actual point values were extracted from the official 2.5 arc-minute BIO archive: BIO12 annual precipitation, BIO13 wettest month, BIO15 precipitation seasonality, BIO16 wettest quarter and BIO17 driest quarter. They are **1970–2000 long-term normals** at about 4.6 km, not event-date or antecedent rainfall. Four background points have source NoData for all five variables; those rows remain in the table and are imputed inside training folds.

The ZIP's central directory was inspected over HTTP byte ranges; GDAL then opened selected TIFF members through the official remote ZIP handler. No global ZIP/TIFF was saved locally; only regional clipped outputs and sampled feature values were retained. WorldClim terms allow academic/non-commercial use; raw data may not be redistributed and commercial use requires prior permission. Attribute WorldClim 2.1; cite Fick and Hijmans (2017), DOI 10.1002/joc.5086. Official pages: [WorldClim historical data](https://www.worldclim.org/data/worldclim21.html), [WorldClim licence](https://www.worldclim.org/about.html).

### Terrain — obtained at ~1 km

WorldClim's 30 arc-second elevation reference surface derived from SRTM supplied elevation for all points; slope, aspect and aspect sine/cosine were derived from it. Elevation and slope have no missing sample values. Aspect direction is undefined at flat/near-flat cells; 41 sample rows retain null aspect components and are imputed inside folds. This is **not 30 m SRTM** and smooths local hillslope relief.

Direct NASA SRTM Global 1 Arc-Second v003 downloads still require Earthdata Login. To obtain the direct 30 m source, create an account at https://urs.earthdata.nasa.gov/users/new, sign in to NASA Earthdata Search, then authorize access to LP DAAC Data Pool/SRTM. WorldClim provided an allowed non-commercial alternative without bypassing NASA registration. Copernicus DEM remains unused pending your personal licence acceptance.

### CHIRPS and ERA5-Land — not used in V2

CHIRPS v3 currently has 25 regional monthly checkpoints (1991-01 through 1993-01) out of the planned 360 for a 1991–2020 baseline. The official CHC server repeatedly rate-limited further retrieval; those partial values were not presented as a climate normal or used in training. The resumable collector is retained in V2. ERA5-Land still requires a CDS account/API setup and your manual acceptance of its terms; no data was downloaded. No event-trigger model was trained because sampled background points have no defensible event dates.

## Version 2 model and matched evaluation

V2 has 14 raw features (22 after WorldCover one-hot encoding): the five existing WorldCover/SoilGrids inputs, five WorldClim rainfall characteristics and elevation, slope, aspect sine and aspect cosine. Raw aspect degrees are retained for reporting but excluded from the model due to circularity. Imputation is fitted inside each training fold; 49 pre-existing missing SoilGrids vectors, 4 WorldClim BIO-missing background rows and 41 undefined aspects were retained.

| Metric | V1 saved spatial OOF | V2 spatial OOF | Change |
|---|---:|---:|---:|
| ROC-AUC | 0.638 | 0.568 | -0.071 |
| Average precision | 0.698 | 0.595 | -0.103 |
| Precision at 0.5 | 0.678 | 0.570 | -0.108 |
| Recall at 0.5 | 0.458 | 0.363 | -0.095 |
| F1 at 0.5 | 0.547 | 0.444 | -0.103 |

V2 confusion matrix (actual background-unknown/event rows, predicted background-unknown/event columns): `[[130,49],[114,65]]`. The features did not improve this experiment's spatial generalization. Because the sample is small and fatality/reporting biased, background outcomes are unknown, and positional precision is not available, these metrics do not establish real-world event probability or operational NER performance. See [model_evaluation_report_v2.md](Version_2/model_evaluation_report_v2.md) and [model_comparison_report.md](Version_2/model_comparison_report.md).

## Saved outputs and integration

Trained V2 artifacts are in `Ashtaraksha_Model/Version_2/`:

- `ashtaraksha_random_forest_v2.joblib`, `preprocessing_pipeline_v2.joblib`
- `training_dataset_v2.csv`, `feature_list_v2.json`, `model_metadata_v2.json`
- `train_random_forest_v2.py`, `predict_v2.py`, `fastapi_example_v2.py`, `requirements.txt`
- `model_evaluation_report_v2.md`, `model_comparison_report.md`, `PROJECT_DEMONSTRATION_REPORT.md`
- `feature_importance_v2.png`, `confusion_matrix_v2.png`
- Regional raster clips and source manifest: `data/worldclim21_ner/`

A real training row (`event_id=467`) yielded the same score `0.9369784686315531` through the saved estimator+pipeline, `predict_v2.py`, reordered input keys and the FastAPI route function. Schema checks rejected missing/extra fields, wrong type, an unseen WorldCover class, NaN and infinity; explicit null continuous fields are imputed and named in the response. Local TestClient `/health` stalled, so HTTP integration is **not yet verified**. The API accepts environmental features, not coordinates; the website must source the 14 valid features before calling it.

Use `fastapi_example_v1_strict.py` or V2's `fastapi_example_v2.py` from the model folder with Uvicorn, then run an HTTP health and prediction test in the deployment environment. The score must be labelled an experimental relative presence-background score, never a calibrated probability or guaranteed early warning.

## Presentation limits

Describe WorldClim BIO values as 1970–2000 long-term normals and the terrain as roughly 1 km SRTM-derived relief. Distinguish modelled WorldClim/SoilGrids surfaces from field measurements. State that V2's matched scores are lower than V1's and retain V1 as the stronger baseline. Do not claim real-time warnings, causal feature effects, confirmed safe background sites, independent NER validation or commercial rights to WorldClim data.
