"""Strict, non-mutating FastAPI adapter for the verified Version 1 artifacts.

Run from this folder with:
    uvicorn fastapi_example_v1_strict:app --host 127.0.0.1 --port 8000
"""
from typing import Annotated

from fastapi import FastAPI
from pydantic import BaseModel, ConfigDict, Field, field_validator

from predict import predict_relative_score


# These are the categories actually represented in V1's fitted one-hot schema.
WORLD_COVER_CODES = {10, 30, 40, 50, 60, 70, 80, 90, 100}
FiniteFloat = Annotated[float, Field(allow_inf_nan=False)]


class PredictorInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    worldcover_class: int = Field(strict=True, description="ESA WorldCover 2021 v200 category code")
    clay_fraction: FiniteFloat = Field(ge=0, le=1, description="SoilGrids clay fraction (0–1)")
    sand_fraction: FiniteFloat = Field(ge=0, le=1, description="SoilGrids sand fraction (0–1)")
    soil_ph: FiniteFloat = Field(gt=0, le=14, description="SoilGrids pH in water")
    soc_stock_t_ha: FiniteFloat = Field(ge=0, description="SoilGrids organic-carbon stock (tonnes/hectare)")

    @field_validator("clay_fraction", "sand_fraction", "soil_ph", "soc_stock_t_ha", mode="before")
    @classmethod
    def require_json_number(cls, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("must be a JSON number")
        return value

    @field_validator("worldcover_class")
    @classmethod
    def validate_worldcover_code(cls, value: int) -> int:
        if value not in WORLD_COVER_CODES:
            raise ValueError("must be a WorldCover category represented in the fitted V1 model")
        return value


app = FastAPI(title="Ashtaraksha Version 1 experimental susceptibility score", version="1.0")


@app.get("/health")
def health():
    return {
        "status": "loaded",
        "model_version": "1",
        "interpretation": "experimental presence-background score; not a calibrated probability",
    }


@app.post("/predict")
def predict(body: PredictorInput):
    return predict_relative_score(body.model_dump())
