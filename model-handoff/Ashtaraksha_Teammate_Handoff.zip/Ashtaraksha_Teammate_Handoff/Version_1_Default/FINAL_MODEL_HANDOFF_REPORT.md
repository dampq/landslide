# Ashtaraksha model handoff

Audit date: 2026-11-11

## Version 1 verification

The saved estimator and preprocessing pipeline both load in the project virtual environment. The estimator is a `RandomForestClassifier` with 13 transformed inputs and classes `[0, 1]`; the preprocessing pipeline accepts the five raw fields listed in `feature_list.json` and transforms them into those 13 fields. The saved transformed feature list matches the pipeline output and estimator width.

A complete real training row (`event_id=467`) produced the same score through direct model inference and `predict.py`: **0.7506392613449581**. Reordered input keys give the same result. `predict.py` currently accepts a missing value (and imputes it), ignores extra fields, accepts an invalid WorldCover string as an unknown category, and imputes NaN. Infinity fails with an unhelpful low-level error. The output is a presence-background score, not a calibrated probability.

The FastAPI request model validates required numeric ranges and rejects missing fields, nonnumeric land-cover, nulls and infinity. Pydantic's default behavior silently ignores extra keys. Direct route-function and schema checks passed for valid/invalid examples. Actual HTTP `TestClient` and ASGI transport requests hung in this environment even against a trivial FastAPI app, so HTTP-level integration is **not verified**.

**Integration status: the new strict adapter is ready for teammate integration, with an HTTP smoke test still outstanding.** Added `fastapi_example_v1_strict.py` as a separate wrapper; it enforces required fields, rejects extras and invalid values, and labels the result as an experimental score. Direct schema/route checks rejected missing, extra, string, invalid WorldCover, NaN and infinity inputs. A real training row (`event_id=467`) returned the same `0.7506392613449581` score as direct model inference. The local TestClient/ASGI transport still hangs even for a trivial app, so the teammate should run one HTTP request in their serving environment. The original `predict.py` and `fastapi_example.py` remain intact.

### V1 request and response

Request JSON fields, in any order:

```json
{"worldcover_class":30,"clay_fraction":0.2,"sand_fraction":0.35,"soil_ph":5.2,"soc_stock_t_ha":25}
```

`worldcover_class` is an ESA WorldCover category code; clay and sand are fractions; `soil_ph` is pH; `soc_stock_t_ha` is tonnes per hectare. The API returns a JSON object containing `experimental_presence_background_score`, an interpretation warning, model region and echoed features. Do not show the score as probability or warning level.

Actual response for the real saved row `event_id=467`:

```json
{"experimental_presence_background_score":0.7506392613449581,"interpretation":"Relative score against this model's sampled unknown backgrounds; not a calibrated landslide probability or warning.","model_region":"North Eastern Region of India; within-region spatial evaluation","features":{"worldcover_class":10,"clay_fraction":0.199,"sand_fraction":0.367,"soil_ph":5.5,"soc_stock_t_ha":170.0}}
```

### Runtime verified

Project environment: Python 3.12.10, NumPy 2.5.4, pandas 3.1.1, scikit-learn 1.6.1, Rasterio 1.5.2, GeoPandas 1.2.0, FastAPI 0.115.8, Pydantic 2.14.3 and HTTPX 0.28.1.

### V1 integrity fingerprints

SHA-256 fingerprints captured before V2 work:

| V1 file | SHA-256 |
|---|---|
| `ashtaraksha_random_forest.joblib` | `6B29B386ACFA9E6434D6CF115B3340C79D4F27BE577F185D6D02D702FC8E7E09` |
| `preprocessing_pipeline.joblib` | `88CBAA98DA6FD661594DEEDD74B20F4977C51ADAA6B7A5B05E2835B53BCB4342` |
| `feature_list.json` | `3A9FDD4141C32E644D83EE6E35DE2EC2A7380F8194A31A707744CE140D2451E5` |
| `model_metadata.json` | `7C6C9806F4F4909E74986C344D68893BB1916E920D148F641EE355D2BBFB271E` |
| `training_dataset.csv` | `4BC3F2B4757A1F8306C932FB867255F02D79C02EC31A704BD468614851E04143` |
| `predict.py` | `D50CD7286BA9B4CDF2DB8B1BBE3DBB717F38DD94AF5C5D3137756DC01989B63C` |
| `fastapi_example.py` | `01B0768C3CC677AE6EB7915CE948C728D067A5B230F53C25F9B41A435D22C93B` |

## Version 2 work in progress

CHIRPS v3 is being collected from the official UCSB CHC monthly COG repository as regional windows for 1991–2020. The collector stores only an NER bounding window and masks output to the eight-state boundary; it does not save global COG files. Version 2 will be trained only after every required monthly window, derived raster and record extraction has been verified. Terrain and ERA5-Land are not currently part of the V2 feature set because the user registration/licence acceptance gates remain open.

