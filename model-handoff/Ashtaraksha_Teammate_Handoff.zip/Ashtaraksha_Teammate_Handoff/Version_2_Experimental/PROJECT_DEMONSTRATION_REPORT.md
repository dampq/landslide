# Ashtaraksha Version 2 demonstration

## What it does

Version 2 is an experimental Random Forest that ranks the sampled NER locations by how similar their static environment is to locations of reported fatal landslides in the training sample. It is **not** a real-time alert, a calibrated landslide probability, or a guarantee that a site will or will not fail.

## Data used

- 179 GFLD reported fatal event occurrences as positive records. All 182 distinct source IDs in those rows match the local author-release GeoJSON subset; three duplicate coordinate/date occurrences were collapsed before the original V1 table was made.
- 179 existing sampled background points, explicitly labelled as unknown landslide outcome, not verified negatives.
- ESA WorldCover 2021 v200 class and SoilGrids 2.0 0–5 cm clay, sand, pH and SOC values already used by V1.
- WorldClim 2.1 BIO12, BIO13, BIO15, BIO16 and BIO17 climate characteristics for 1970–2000, at 2.5 arc-minute (~4.6 km). These are long-term climate normals, not measurements taken on landslide dates.
- WorldClim 2.1 SRTM-derived elevation at 30 arc-seconds (~1 km); slope and aspect were derived from this grid. This terrain is much coarser than 30 m hillside terrain.

The observations represent all eight states. Sample counts (events + unknown backgrounds) are Arunachal Pradesh 64, Assam 124, Manipur 16, Meghalaya 54, Mizoram 28, Nagaland 8, Sikkim 54 and Tripura 10.

The records and predictors represent different kinds of evidence: GFLD points are reported fatal events with uncertain positional accuracy; WorldClim BIO values are modelled 1970–2000 climate normals; WorldClim elevation is an approximately 1 km SRTM-derived surface; SoilGrids values are modelled soil estimates; and WorldCover is a 2021 land-cover classification. No event rainfall measurements, synthetic events, or fabricated environmental values were added. The application example uses an actual saved training row.

## How the features relate to susceptibility

Rainfall normals provide broad wetness and seasonality context; they do not say how much it rained in the hours or days before an event. Elevation and slope describe broad relief, while aspect sine/cosine encode the direction a slope faces without treating 359° and 1° as far apart. Land cover and modelled soil properties add surface/soil context. These correlations do not establish causation.

The largest training-fit impurity importances were BIO16 wettest-quarter rainfall (0.169), WorldCover class 50 (0.096), elevation (0.093), slope (0.082) and BIO12 annual rainfall (0.071). These values describe how this fitted forest used the small training sample; they are not causal effects or proof of robust population importance.

## Evaluation

Matched spatial cross-validation results: ROC-AUC 0.568; average precision 0.595; precision 0.570; recall 0.363; F1 0.444 at score threshold 0.5. Version 2 versus Version 1 results and changes are in `model_comparison_report.md`. These are within-region grouped estimates for the sampled case/background design, not independent validation or real-world probability estimates.

## Limitations and next development steps

GFLD records are fatality/reporting biased and their exported points have no per-record location precision. Background points can include unreported landslides. The sample is small; 4 background rows have missing BIO values, 41 rows have undefined aspect on flat/near-flat terrain, and 49 retain missing V1 soil values. Fold-local imputation retains those rows. WorldCover is from 2021; rainfall normal is 1970–2000; elevation/slope is about 1 km. Do not present this as an early-warning system or as validated state-wide susceptibility.

For a later research phase, obtain a well-located local inventory and independent event dates, add licensed finer-resolution DEM and antecedent rainfall matched to both event and background times, test alternative background sampling designs, and validate on held-out locations/time periods. WorldClim is academic/non-commercial only: do not redistribute raw data or use commercially without prior permission. Any website demo should label returned values as experimental relative scores; simulated interface examples must be distinguished from actual observed events. No regional prediction map was produced because V2 performed below V1 on the matched spatial evaluation and there is no independent NER validation.

