# Version 2 model evaluation

## Model and data

This separate `RandomForestClassifier` used 179 GFLD-reported fatal landslide occurrences and 179 sampled background locations with unknown outcome. The same rows, source IDs and 100 km outer spatial blocks were used for V1 and V2. V1 was not retrained. V2 uses 14 raw predictors (22 after categorical encoding): WorldCover, four SoilGrids properties, five WorldClim 2.1 precipitation normals and four terrain encodings (elevation, slope, aspect sine/cosine). Raw aspect degrees are kept in the CSV but excluded from model input because azimuth is circular.

All missing-value imputation is fitted within each training fold (median for continuous inputs, most frequent for WorldCover). No rows were removed for missing environmental values. Four background rows have missing WorldClim BIO cells; 41 rows have undefined aspect direction on flat/near-flat terrain; 49 rows retain V1's missing soil vector.

## Nested spatial out-of-fold performance

| Metric | Version 1 | Version 2 | Change |
|---|---:|---:|---:|
| ROC-AUC | 0.638 | 0.568 | -0.071 |
| Average precision | 0.698 | 0.595 | -0.103 |
| Precision at 0.5 | 0.678 | 0.570 | -0.108 |
| Recall at 0.5 | 0.458 | 0.363 | -0.095 |
| F1 at 0.5 | 0.547 | 0.444 | -0.103 |

Version 2 confusion matrix (`actual rows: background unknown, GFLD event; predicted columns in same order`): `[[130, 49], [114, 65]]`. The matched-fold results show whether the added data helped this particular sampled design; they do not establish population-level prediction performance. See `model_comparison_report.md` for the interpretation of changes.

## Important limits

- The label 0 records are background samples with unknown landslide status; they are not true negatives. With a 1:1 case/background sample, precision and scores are not calibrated real-world probabilities.
- GFLD is fatality/reporting-biased; event points lack record-specific positional uncertainty geometries. Raster values may not describe the initiation site.
- WorldClim precipitation predictors are 1970–2000 climate normals at ~4.6 km, not daily rainfall before events. This is a static susceptibility experiment, not a trigger or early-warning model.
- The elevation surface is WorldClim's SRTM-derived 30 arc-second (~1 km) product. Slope/aspect at that resolution smooth local hillslope terrain and are not equivalent to 30 m SRTM measurements.
- WorldCover 2021 is later than many 2004–2016 events; SoilGrids are modelled predictions. No independent temporal or external validation was done.
- WorldClim is restricted to academic/non-commercial use and its data may not be redistributed or used commercially without prior permission. Do not publish raw source rasters or derived raster values without checking permission.
- Feature importance is impurity-based and descriptive, not causal.
