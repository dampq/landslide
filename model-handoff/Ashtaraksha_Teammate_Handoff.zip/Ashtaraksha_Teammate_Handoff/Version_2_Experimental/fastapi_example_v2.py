"""Strict FastAPI wrapper for Version 2; run with uvicorn fastapi_example_v2:app."""
from typing import Annotated
from fastapi import FastAPI
from pydantic import BaseModel, ConfigDict, Field, field_validator
from predict_v2 import WORLDCOVER_CODES, predict_relative_score

Finite = Annotated[float, Field(strict=True, allow_inf_nan=False)]
OptionalFinite = Annotated[float | None, Field(strict=True, allow_inf_nan=False)]


class PredictorInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    worldcover_class: int = Field(strict=True)
    clay_fraction: Finite
    sand_fraction: Finite
    soil_ph: Finite
    soc_stock_t_ha: Finite
    bio12_annual_precipitation_mm: OptionalFinite
    bio13_wettest_month_precip_mm: OptionalFinite
    bio15_precipitation_seasonality_pct: OptionalFinite
    bio16_wettest_quarter_precip_mm: OptionalFinite
    bio17_driest_quarter_precip_mm: OptionalFinite
    elevation_m: Finite
    slope_degrees: Finite
    aspect_sin: OptionalFinite
    aspect_cos: OptionalFinite

    @field_validator("worldcover_class")
    @classmethod
    def valid_worldcover_training_class(cls, value: int) -> int:
        if value not in WORLDCOVER_CODES:
            raise ValueError("must be a WorldCover class represented in the training observations")
        return value

    @field_validator("clay_fraction", "sand_fraction")
    @classmethod
    def valid_fractions(cls, value: float) -> float:
        if not 0 <= value <= 1:
            raise ValueError("must be between 0 and 1")
        return value

    @field_validator("soil_ph")
    @classmethod
    def valid_ph(cls, value: float) -> float:
        if not 0 <= value <= 14:
            raise ValueError("must be between 0 and 14")
        return value

    @field_validator("soc_stock_t_ha", "bio12_annual_precipitation_mm", "bio13_wettest_month_precip_mm",
                     "bio15_precipitation_seasonality_pct", "bio16_wettest_quarter_precip_mm",
                     "bio17_driest_quarter_precip_mm")
    @classmethod
    def nonnegative_measurement(cls, value):
        if value is not None and value < 0:
            raise ValueError("must be nonnegative")
        return value

    @field_validator("elevation_m")
    @classmethod
    def valid_elevation(cls, value: float) -> float:
        if not -500 <= value <= 9000:
            raise ValueError("must be between -500 and 9000 metres")
        return value

    @field_validator("slope_degrees")
    @classmethod
    def valid_slope(cls, value: float) -> float:
        if not 0 <= value <= 90:
            raise ValueError("must be between 0 and 90 degrees")
        return value

    @field_validator("aspect_sin", "aspect_cos")
    @classmethod
    def valid_aspect_component(cls, value):
        if value is not None and not -1 <= value <= 1:
            raise ValueError("must be between -1 and 1")
        return value


app = FastAPI(title="Ashtaraksha Version 2 experimental susceptibility score", version="2.0")


@app.get("/health")
def health():
    return {"status": "loaded", "model_version": "2",
            "interpretation": "experimental presence-background score; not a calibrated probability"}


@app.post("/predict")
def predict(body: PredictorInput):
    return predict_relative_score(body.model_dump())
