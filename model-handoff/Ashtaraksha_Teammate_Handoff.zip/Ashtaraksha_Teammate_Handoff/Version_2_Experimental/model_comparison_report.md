# Version 1 versus Version 2

This is a matched-observation and matched-outer-fold comparison: both models use the same 179 positive event occurrences, 179 sampled unknown-background rows, and the same saved 100 km block sets. The V1 fitted model was not retrained. V2's imputation/model tuning was performed inside its training folds.

| Metric | V1 | V2 | Change |
|---|---:|---:|---:|
| ROC-AUC | 0.638 | 0.568 | -0.071 |
| Average precision | 0.698 | 0.595 | -0.103 |
| Precision at 0.5 | 0.678 | 0.570 | -0.108 |
| Recall at 0.5 | 0.458 | 0.363 | -0.095 |
| F1 at 0.5 | 0.547 | 0.444 | -0.103 |

## Interpretation

Both ROC-AUC and average precision fell on these matched folds. The added variables did not improve this experiment's spatial generalization; keep V1 as the stronger baseline by these metrics.

Both models classify recorded GFLD fatal events against a selected sample of locations with unknown outcome. These metrics are not calibrated landslide probabilities and do not measure a real-world false-alarm rate. V2 adds WorldClim 1970–2000 climate normals, ~1 km SRTM-derived terrain and the existing land-cover/soil variables. The WorldClim predictors are academic/non-commercial only; no commercial or public data redistribution is permitted without prior permission.
